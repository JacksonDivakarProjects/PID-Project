import cv2
import pandas as pd
import numpy as np
import uuid
import json
from scipy.spatial import KDTree

# ---------------------------
# 1. Load Components from Excel
# ---------------------------
def load_components_from_excel(excel_path):
    """Loads component data from an Excel file into a list of node objects."""
    try:
        df = pd.read_excel(excel_path)
    except FileNotFoundError:
        print(f"🛑 Error: The file '{excel_path}' was not found.")
        return None, None
        
    nodes = []
    comp_centers = []

    for _, row in df.iterrows():
        x, y, w, h = row["x"], row["y"], row["width"], row["height"]
        bbox = [x, y, x + w, y + h]
        node_id = str(uuid.uuid4())
        
        # Safely get the class_id or a default value
        class_id_value = row.get("class", "N/A")

        node = {
            "id": node_id,
            "label": row["Component Name"],
            "type": str(class_id_value),
            "bbox": bbox,
            "component_id": str(row["extracted_text"])
        }
        nodes.append(node)

        center = ((x + x + w) / 2, (y + y + h) / 2)
        comp_centers.append((center, node_id))

    return nodes, comp_centers

# ---------------------------
# 2. Detect Pipes (Hough Lines)
# ---------------------------
def detect_pipes(image_path):
    """Detects straight lines in an image to represent pipes."""
    try:
        img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            print(f"🛑 Error: Could not read the image file at '{image_path}'.")
            return []
    except Exception as e:
        print(f"🛑 Error loading image: {e}")
        return []
        
    edges = cv2.Canny(img, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=80,
                            minLineLength=40, maxLineGap=15)

    pipes = []
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            pipes.append(((x1, y1), (x2, y2)))
    return pipes

# ---------------------------
# 3. Build Graph Using KDTree
# ---------------------------
def build_graph_with_kdtree(pipes, comp_centers):
    """Connects pipes to the nearest components and calculates confidence."""
    centers = np.array([c[0] for c in comp_centers])
    ids = [c[1] for c in comp_centers]
    
    if not centers.any():
        return []
        
    tree = KDTree(centers)
    edges = []
    
    MAX_SNAP_DISTANCE = 50.0

    for (p1, p2) in pipes:
        dist1, idx1 = tree.query(p1)
        dist2, idx2 = tree.query(p2)
        comp1_id = ids[idx1]
        comp2_id = ids[idx2]

        if comp1_id != comp2_id:
            length = np.linalg.norm(np.array(p1) - np.array(p2))
            flag = "OK"
            if dist1 > MAX_SNAP_DISTANCE or dist2 > MAX_SNAP_DISTANCE:
                flag = "LOW_CONFIDENCE_CONNECTION"
            
            avg_dist = (dist1 + dist2) / 2.0
            confidence_score = max(0, 1.0 - (avg_dist / MAX_SNAP_DISTANCE))
            
            edge = {
                "from": comp1_id,
                "to": comp2_id,
                "length": float(length),
                "confidence_score": round(confidence_score, 3),
                "flag": flag
            }
            
            if not any(((e["from"] == edge["from"] and e["to"] == edge["to"]) or
                        (e["from"] == edge["to"] and e["to"] == edge["from"]))
                       for e in edges):
                edges.append(edge)
    return edges

# ---------------------------
# 4. Export to JSON
# ---------------------------
def export_to_json(nodes, edges, out_path):
    """Saves the final nodes and edges to a JSON file."""
    graph = {"nodes": nodes, "edges": edges}
    with open(out_path, "w") as f:
        json.dump(graph, f, indent=2)

# ---------------------------
# 5. Print Summary of Connections
# ---------------------------
def print_graph_summary(nodes, edges):
    """Prints a detailed, human-readable summary of all connections."""
    print("\n--- 📊 P&ID Connection Summary ---")
    
    node_map = {node['id']: node for node in nodes}
    
    if not edges:
        print("No connections were found.")
        return

    for i, edge in enumerate(edges):
        from_node = node_map.get(edge['from'])
        to_node = node_map.get(edge['to'])
        
        if not from_node or not to_node:
            continue

        from_label = f"{from_node['label']} ({from_node['component_id']})"
        to_label = f"{to_node['label']} ({to_node['component_id']})"
        score = edge['confidence_score']
        flag = edge['flag']
        
        flag_icon = "⚠️" if flag == "LOW_CONFIDENCE_CONNECTION" else "✅"

        print(f"\n🔗 Connection #{i+1}:")
        print(f"   ➡️ From: {from_label}")
        print(f"   ➡️ To:   {to_label}")
        print(f"   {flag_icon} Confidence: {score} ({flag})")

# ---------------------------------------------
# 6. Generate DataFrame Statistics (NEW)
# ---------------------------------------------
def generate_pipe_statistics(nodes, edges):
    """Creates a pandas DataFrame with detailed stats for every pipe."""
    
    node_map = {node['id']: node for node in nodes}
    records = []

    for edge in edges:
        from_node = node_map.get(edge['from'])
        to_node = node_map.get(edge['to'])

        if not from_node or not to_node:
            continue
            
        records.append({
            "From Component": from_node['label'],
            "From Tag": from_node['component_id'],
            "To Component": to_node['label'],
            "To Tag": to_node['component_id'],
            "Length (px)": round(edge['length'], 2),
            "Confidence Score": edge['confidence_score'],
            "Status": "Low Confidence" if edge['flag'] == "LOW_CONFIDENCE_CONNECTION" else "High Confidence"
        })
        
    if not records:
        print("\n--- 📈 Pipe Statistics ---")
        print("No data available to generate statistics.")
        return None
        
    return pd.DataFrame(records)

# ---------------------------
# Main Pipeline
# ---------------------------
if __name__ == "__main__":
    excel_path = "predictions_with_components.xlsx"
    image_path = "0.jpg"
    out_json = "graph.json"

    # 1. Load components
    nodes, comp_centers = load_components_from_excel(excel_path)
    
    if nodes:
        # 2. Detect pipes
        pipes = detect_pipes(image_path)
        
        # 3. Build connections
        edges = build_graph_with_kdtree(pipes, comp_centers)
        
        # 4. Export JSON
        export_to_json(nodes, edges, out_json) #------> Exporting Json


        # --- 6. Generate and Print DataFrame Statistics (NEW) ---
        pipe_stats_df = generate_pipe_statistics(nodes, edges)
        
        if pipe_stats_df is not None:
            print("\n\n--- 📈 Pipe Statistics (DataFrame) ---")
            # Using to_string() to ensure the full DataFrame is printed
            pipe_stats_df=pipe_stats_df[pipe_stats_df['Status']=="Low Confidence"]
            print(pipe_stats_df)

        else:
            print("No values to show") # No value o/p
            

           
