import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { X, Bot, Paperclip, ArrowUp } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';
import { GoogleGenerativeAI, ChatSession, Part } from "@google/generative-ai";
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useUpload } from '@/context/UploadContext';

// Helper function to convert a File object to a Gemini-compatible format
async function fileToGenerativePart(file: File): Promise<Part> {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
}

interface ChatbotProps {
  onClose: () => void;
}

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

const Chatbot: React.FC<ChatbotProps> = ({ onClose }) => {
  const [messages, setMessages] = useState<{ text: string; sender: 'user' | 'bot'; image?: string }[]>([
    { sender: 'bot', text: "Hello! I'm PIDFlow's AI assistant. How can I help you? You can also send me an image." }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [usedSuggestionNames, setUsedSuggestionNames] = useState<string[]>([]);
  
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { uploadQueue } = useUpload();

  const suggestedImages = useMemo(() => {
    const contextImages = uploadQueue
        .filter(item => item.status === 'completed' && item.result && item.file.type.startsWith('image/'))
        .map(item => item.file);
    const allImages = [...uploadedImages, ...contextImages];
    const uniqueImages = Array.from(new Map(allImages.map(file => [file.name, file])).values());
    return uniqueImages.filter(file => !usedSuggestionNames.includes(file.name));
  }, [uploadQueue, uploadedImages, usedSuggestionNames]);

  const chatSession = useMemo<ChatSession | null>(() => {
    if (!API_KEY) {
      setError("API key not found. Please add VITE_GEMINI_API_KEY to your .env file.");
      return null;
    }
    const genAI = new GoogleGenerativeAI(API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    
    return model.startChat({
      history: [
        { role: "user", parts: [{ text: "You are an expert assistant for a P&ID (Piping and Instrumentation Diagram) analysis application. Your name is PIDFlow. Be helpful and concise." }] },
        { role: "model", parts: [{ text: "Understood. I am PIDFlow, an expert assistant for P&ID analysis. How can I assist you today?" }] },
      ],
    });
  }, []);

  const scrollToBottom = () => {
    const viewport = scrollAreaRef.current?.querySelector('div[data-radix-scroll-area-viewport]');
    if (viewport) {
      viewport.scrollTop = viewport.scrollHeight;
    }
  };

  useEffect(() => {
    setTimeout(scrollToBottom, 100);
  }, [messages, isTyping]);
  
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
        const newFiles = Array.from(files).filter(file =>
            file.type.startsWith("image/") &&
            !uploadedImages.some(existingFile => existingFile.name === file.name) &&
            imageFile?.name !== file.name
        );
        if (newFiles.length > 0) {
            setUploadedImages(prev => [...prev, ...newFiles]);
        }
    }
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const removeImage = () => {
      setImageFile(null);
      if (imagePreview) {
          URL.revokeObjectURL(imagePreview);
          setImagePreview(null);
      }
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
  };

  const handleBubbleClick = (fileToAttach: File) => {
    if (imagePreview) {
        URL.revokeObjectURL(imagePreview);
    }
    setImageFile(fileToAttach);
    setImagePreview(URL.createObjectURL(fileToAttach));
    setUsedSuggestionNames(prev => [...prev, fileToAttach.name]);
  };

  const handleSendMessage = async () => {
    const textToSend = inputValue.trim();
    if ((textToSend === '' && !imageFile) || !chatSession || isTyping) return;

    setMessages(prev => [...prev, { text: textToSend, sender: 'user' as const, image: imagePreview }]);
    setMessages(prev => [...prev, { text: "", sender: 'bot' as const }]);
    
    setInputValue('');
    setIsTyping(true);
    setError(null);

    try {
      const promptParts: (string | Part)[] = [];
      if (imageFile) {
        const imagePart = await fileToGenerativePart(imageFile);
        promptParts.push(imagePart);
      }
      if (textToSend) {
        promptParts.push(textToSend);
      }
      
      removeImage();

      const stream = await chatSession.sendMessageStream(promptParts);

      let botResponseText = "";
      for await (const chunk of stream.stream) {
        const chunkText = chunk.text();
        botResponseText += chunkText;
        
        setMessages(prev => {
          const updatedMessages = [...prev];
          updatedMessages[updatedMessages.length - 1].text = botResponseText;
          return updatedMessages;
        });
      }

    } catch (err) {
      console.error("Gemini API stream error:", err);
      const errorMessage = "Sorry, an error occurred while processing your request.";
       setMessages(prev => {
          const updatedMessages = [...prev];
          updatedMessages[updatedMessages.length - 1].text = errorMessage;
          return updatedMessages;
      });
      setError(errorMessage);
    } finally {
      setIsTyping(false);
    }
  };
  
  const lastMessage = messages[messages.length - 1];
  const showStaticTypingDots = isTyping && lastMessage?.sender === 'bot' && lastMessage.text === "";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="absolute top-5 bottom-5 right-5 w-[360px] bg-card shadow-2xl rounded-2xl flex flex-col z-50 border"
    >
      <div className="flex justify-between items-center p-3 border-b">
        <div className="flex items-center gap-3">
          <Bot className="h-6 w-6 text-primary" />
          <div>
            <h3 className="font-semibold">PIDFlow Assistant</h3>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-green-500" />
              <p className="text-xs text-muted-foreground">Online</p>
            </div>
          </div>
        </div>
        <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8 rounded-full"> <X className="h-4 w-4" /> </Button>
        </div>
      </div>

      <ScrollArea className="flex-1" ref={scrollAreaRef}>
        <div className="p-4 space-y-4">
          <AnimatePresence>
            {messages.map((msg, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn("flex items-end gap-2 w-full", msg.sender === 'user' ? 'justify-end' : 'justify-start')}
                >
                  <div className={cn("rounded-2xl px-4 py-2 max-w-[85%]", msg.sender === 'user' ? 'bg-border text-foreground' : 'bg-muted')}>
                    {msg.image && (
                        <div className="rounded-lg mb-2 p-2 bg-secondary max-w-full h-auto flex justify-center items-center">
                            <img src={msg.image} alt="User upload" className="rounded-md max-w-full h-auto" />
                        </div>
                    )}
                    <div className="prose prose-sm dark:prose-invert max-w-none prose-p:my-0">
                      <ReactMarkdown remarkPlugins={[remarkGfm]}>
                        {msg.text}
                      </ReactMarkdown>
                      {index === messages.length - 1 && msg.sender === 'bot' && isTyping && msg.text !== "" && (
                          <span className="inline-block w-2 h-4 bg-primary animate-pulse ml-1" />
                      )}
                    </div>
                  </div>
                </motion.div>
              )
            )}
          </AnimatePresence>
          {showStaticTypingDots && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex items-end gap-2 justify-start">
              <div className="rounded-2xl px-4 py-3 bg-muted flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 bg-foreground/70 rounded-full animate-bounce [animation-delay:-0.3s]" />
                <span className="h-1.5 w-1.5 bg-foreground/70 rounded-full animate-bounce [animation-delay:-0.15s]" />
                <span className="h-1.5 w-1.5 bg-foreground/70 rounded-full animate-bounce" />
              </div>
            </motion.div>
          )}
           {error && !API_KEY && (
              <div className="rounded-lg bg-destructive/10 border border-destructive text-destructive p-3 text-sm">
                  <p className="font-bold">Configuration Error</p>
                  <p>{error}</p>
              </div>
          )}
        </div>
      </ScrollArea>

      {/* --- MODIFIED: Suggestions are now here, above the input --- */}
      <div className="p-3 border-t">
        {suggestedImages.length > 0 && (
            <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex flex-col items-start gap-2 mb-3"
            >
                <div className="text-xs text-muted-foreground w-full">Suggestions (click to attach):</div>
                <div className="flex flex-wrap gap-2">
                    {suggestedImages.map((file, index) => (
                        <Button
                            key={`${file.name}-${index}`}
                            variant="outline"
                            size="sm"
                            className="rounded-full h-auto py-1 px-3 text-sm cursor-pointer"
                            onClick={() => handleBubbleClick(file)}
                        >
                            {file.name}
                        </Button>
                    ))}
                </div>
            </motion.div>
        )}
        {imagePreview && (
          <div className="mb-2 relative w-20 h-20">
            <img src={imagePreview} alt="Preview" className="w-full h-full object-cover rounded-md" />
            <Button size="icon" variant="destructive" className="absolute -top-2 -right-2 h-6 w-6 rounded-full" onClick={removeImage}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
        <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }} className="relative">
          <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" multiple />
          <Button type="button" size="icon" variant="ghost" className="absolute left-1 top-1/2 -translate-y-1/2 h-9 w-9 rounded-full" onClick={() => fileInputRef.current?.click()}>
              <Paperclip className="h-5 w-5" />
          </Button>
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={error ? "Chat is disabled" : (imageFile ? "Add a caption or send the image..." : "Ask about your P&ID...")}
            className="rounded-lg pl-12 pr-12 h-11 dark:text-muted-foreground"
            autoComplete="off"
            disabled={isTyping || !!error}
          />
          <Button type="submit" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8 rounded-md" disabled={(!inputValue.trim() && !imageFile) || isTyping || !!error}>
            <ArrowUp className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </motion.div>
  );
};

export default Chatbot;