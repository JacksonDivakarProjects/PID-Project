import * as React from "react"
import { Slot } from "@radix-ui/react-slot"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium ring-offset-background transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-industrial hover:shadow-elegant",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-industrial",
        outline: "border border-border bg-background hover:bg-accent hover:text-accent-foreground hover:border-primary/50",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 shadow-industrial hover:shadow-elegant",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
        
        // --- PREVIOUSLY ADDED VARIANT ---
        "violet-gradient": "bg-gradient-to-r from-[#AF85FE] to-[#8A4FFF] text-white hover:shadow-lg hover:scale-105 shadow-md",
        
        // --- NEW VARIANTS ADDED HERE ---
        "maroon": "bg-[#722E3D] text-white hover:bg-[#5f2632] shadow-md",
        "mint-green": "bg-[#65DF9C] text-black hover:bg-[#52c986] shadow-md",
        "earth-gradient": "bg-gradient-to-r from-[#C5BAB0] to-[#4E403B] text-white hover:shadow-lg hover:scale-105 shadow-md",

        // Industrial gradient variants
        gradient: "bg-gradient-primary text-primary-foreground hover:shadow-glow hover:scale-105 shadow-industrial",
        "gradient-secondary": "bg-gradient-secondary text-secondary-foreground hover:shadow-glow hover:scale-105 shadow-industrial",
        // Glow variant for hero sections
        glow: "bg-primary text-primary-foreground hover:bg-primary/90 shadow-glow hover:shadow-elegant animate-glow-pulse",
        // Industrial outline with glow
        "outline-glow": "border border-primary/50 bg-background/80 text-primary hover:bg-primary hover:text-primary-foreground hover:shadow-glow backdrop-blur-sm",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-12 rounded-lg px-8 text-base",
        xl: "h-14 rounded-xl px-10 text-lg",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button"
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button, buttonVariants }