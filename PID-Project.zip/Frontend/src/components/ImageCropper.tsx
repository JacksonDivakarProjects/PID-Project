import React, { useState, useRef } from 'react';
import ReactCrop, {
  type Crop,
  centerCrop,
  makeAspectCrop,
  PixelCrop,
} from 'react-image-crop';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

interface ImageCropperProps {
  imageSrc: string;
  originalFile: File;
  onCropComplete: (croppedFile: File) => void;
  onClose: () => void; // This is now for the "Cancel" button
}

// Function to generate the cropped image file
async function getCroppedImg(
  image: HTMLImageElement,
  crop: PixelCrop,
  fileName: string,
  fileType: string
): Promise<File> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  if (!ctx) {
    throw new Error('No 2d context');
  }

  const scaleX = image.naturalWidth / image.width;
  const scaleY = image.naturalHeight / image.height;

  canvas.width = Math.floor(crop.width * scaleX);
  canvas.height = Math.floor(crop.height * scaleY);

  ctx.drawImage(
    image,
    crop.x * scaleX,
    crop.y * scaleY,
    crop.width * scaleX,
    crop.height * scaleY,
    0,
    0,
    canvas.width,
    canvas.height
  );

  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          reject(new Error('Canvas is empty'));
          return;
        }
        const croppedFile = new File([blob], fileName, { type: fileType });
        resolve(croppedFile);
      },
      fileType,
      1
    );
  });
}


const ImageCropper: React.FC<ImageCropperProps> = ({
  imageSrc,
  originalFile,
  onCropComplete,
  onClose,
}) => {
  const imgRef = useRef<HTMLImageElement>(null);
  const [crop, setCrop] = useState<Crop>();
  const [completedCrop, setCompletedCrop] = useState<PixelCrop>();
  const [isProcessing, setIsProcessing] = useState(false);

  function onImageLoad(e: React.SyntheticEvent<HTMLImageElement>) {
    const { width, height } = e.currentTarget;
    const initialCrop = centerCrop(
      makeAspectCrop({ unit: '%', width: 90 }, 16 / 9, width, height),
      width,
      height
    );
    setCrop(initialCrop);
    setCompletedCrop({
      unit: 'px',
      x: (width * (1 - 0.9)) / 2,
      y: (height * (1 - (0.9 * 9) / 16)) / 2,
      width: width * 0.9,
      height: (width * 0.9 * 9) / 16
    });
  }

  const handleCrop = async () => {
    if (imgRef.current && completedCrop?.width && completedCrop?.height) {
      setIsProcessing(true);
      try {
        const croppedFile = await getCroppedImg(
          imgRef.current,
          completedCrop,
          originalFile.name,
          originalFile.type
        );
        onCropComplete(croppedFile);
      } catch (error) {
        console.error('Error cropping image:', error);
      } finally {
        setIsProcessing(false);
      }
    }
  };

  return (
    <Card className="p-4 sm:p-6 mb-8">
      <CardHeader className="px-2 sm:px-4">
        <CardTitle>Crop Image</CardTitle>
        <CardDescription>
          Adjust the selection to focus on the desired area before uploading.
        </CardDescription>
      </CardHeader>
      <CardContent className="px-2 sm:px-4">
        <div className="flex justify-center items-center">
            <ReactCrop
                crop={crop}
                onChange={(_, percentCrop) => setCrop(percentCrop)}
                onComplete={(c) => setCompletedCrop(c)}
                className="max-h-[60vh]"
            >
                <img
                    ref={imgRef}
                    alt="Crop preview"
                    src={imageSrc}
                    onLoad={onImageLoad}
                    style={{ maxHeight: '55vh' }}
                />
            </ReactCrop>
        </div>
      </CardContent>
      <CardFooter className="flex justify-end space-x-2 px-2 sm:px-4">
        <Button variant="outline" onClick={onClose} disabled={isProcessing}>
          Cancel
        </Button>
        <Button onClick={handleCrop} disabled={!completedCrop || isProcessing}>
          {isProcessing ? 'Processing...' : 'Crop & Upload'}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default ImageCropper;