/* eslint-disable @typescript-eslint/no-explicit-any */
import { useUpload } from "@/context/UploadContext";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Download, FileJson, FileSpreadsheet, FileText, FileCode } from "lucide-react";
import { Link } from "react-router-dom";
import { UploadQueueItem } from "@/context/UploadContext"; 
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import * as XLSX from 'xlsx';

type ResultWithId = UploadQueueItem['result'] & { id: string; file: File };

// Reusable component for the styled export buttons
const ExportButton = ({ format, icon, onClick, disabled, label }: { format: string; icon: React.ReactNode; onClick: () => void; disabled: boolean; label?: string; }) => (
    <Button variant="outline" className="w-full justify-start text-left h-auto min-h-[4rem] p-4 hover-lift whitespace-normal items-start" onClick={onClick} disabled={disabled}>
        <div className="mr-4 h-6 w-6 flex-shrink-0 mt-1">{icon}</div>
        <div className="flex-1">
            <p className="font-semibold text-base leading-tight">{label || `Export .${format}`}</p>
            <p className="text-xs text-muted-foreground">{format.toUpperCase()} format</p>
        </div>
    </Button>
);

const Export = () => {
  const { uploadQueue } = useUpload();
  const { toast } = useToast();

  const results: ResultWithId[] = uploadQueue
    .filter((item): item is UploadQueueItem & { result: NonNullable<UploadQueueItem['result']> } => 
        item.status === 'completed' && !!item.result
    )
    .map(item => ({
        id: item.id,
        ...item.result,
        file: item.file,
    }));

  const getBaseFileName = (fileName: string) => {
    return fileName.substring(0, fileName.lastIndexOf('.')) || fileName;
  };

  const downloadBlob = (blob: Blob, fileName: string) => {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  };

  const base64ToBlob = (base64: string, mimeType: string): Blob => {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
  }

  const handleExport = (format: 'json' | 'excel' | 'xml' | 'csv', result?: ResultWithId) => {
    if (!result || !result.isEnhanced) {
        toast({
            title: "Analysis Required",
            description: "Please analyze the data on the Results page before exporting.",
            variant: "destructive",
        });
        return;
    }

    const baseName = `pid_export_${getBaseFileName(result.originalFileName)}`;

    try {
        if (format === 'json' && result.industrialJson) {
            const blob = base64ToBlob(result.industrialJson, 'application/json');
            downloadBlob(blob, `${baseName}.json`);
        } else if (format === 'excel' && result.statisticsExcel) {
            const blob = base64ToBlob(result.statisticsExcel, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            downloadBlob(blob, `${baseName}_statistics.xlsx`);
        } else if (format === 'xml' && result.dexpiXml) {
            const blob = base64ToBlob(result.dexpiXml, 'application/xml');
            downloadBlob(blob, `${baseName}.xml`);
        } else if (format === 'csv' && result.statisticsExcel) {
            const excelBytes = atob(result.statisticsExcel);
            const excelArray = new Uint8Array(excelBytes.length).map((_, i) => excelBytes.charCodeAt(i));
            
            const workbook = XLSX.read(excelArray, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];

            const csvString = XLSX.utils.sheet_to_csv(worksheet);
            const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
            downloadBlob(blob, `${baseName}_statistics.csv`);
        } else {
            throw new Error(`Export data for .${format} not available.`);
        }
    } catch (error: any) {
        toast({
            title: "Export Failed",
            description: error.message || "An unexpected error occurred during export.",
            variant: "destructive",
        });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-mesh py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <div className="text-center mb-12">
                <div className="mx-auto w-24 h-24 mb-6 rounded-full bg-gradient-primary flex items-center justify-center animate-glow-pulse">
                    <Download className="h-12 w-12 text-primary-foreground" />
                </div>
                <h1 className="text-4xl font-bold mb-4">Export Digitalized Data</h1>
                <p className="text-xl text-muted-foreground">
                    Download your generated P&ID Digitalized data in various structured formats.
                </p>
            </div>
        </motion.div>

        {results.length > 0 ? (
          <div className="space-y-8">
            {results.map((result, index) => (
                <motion.div 
                    key={result.id}
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                    <Card className="p-6 md:p-8 industrial-card overflow-hidden">
                        <div className="grid md:grid-cols-2 gap-8 items-center">
                            {/* Left side: File Info */}
                            <div className="space-y-3">
                                <FileText className="h-12 w-12 text-primary" />
                                <h3 className="text-2xl font-bold text-primary truncate" title={result.originalFileName}>
                                    {result.originalFileName}
                                </h3>
                                <p className="text-muted-foreground">
                                    {result.isEnhanced
                                        ? "Analysis complete and ready for export."
                                        : "Analysis required before exporting."}
                                </p>
                                {result.componentData && (
                                    <p className="text-sm text-muted-foreground">
                                        <strong>{result.componentData.length}</strong> components detected.
                                    </p>
                                )}
                            </div>
                            {/* Right side: Export Options */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <ExportButton format="excel" icon={<FileSpreadsheet />} onClick={() => handleExport('excel', result)} disabled={!result.isEnhanced} />
                                <ExportButton format="json" icon={<FileJson />} onClick={() => handleExport('json', result)} disabled={!result.isEnhanced} />
                                <ExportButton format="csv" icon={<FileText />} onClick={() => handleExport('csv', result)} disabled={!result.isEnhanced} />
                                <ExportButton format="dexpi XML" icon={<FileCode />} onClick={() => handleExport('xml', result)} disabled={!result.isEnhanced} label="Export .xml" />
                            </div>
                        </div>
                    </Card>
                </motion.div>
            ))}
          </div>
        ) : (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}>
            <Card className="p-12 industrial-card">
                <div className="text-center text-muted-foreground">
                    <h3 className="text-2xl font-semibold text-foreground mb-4">No Data to Export</h3>
                    <p className="mb-6">
                        Please <Link to="/upload" className="text-primary font-semibold hover:underline">upload and analyze a P&ID</Link> to generate graph data.
                    </p>
                    <Button asChild>
                        <Link to="/upload">Upload a File</Link>
                    </Button>
                </div>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default Export;