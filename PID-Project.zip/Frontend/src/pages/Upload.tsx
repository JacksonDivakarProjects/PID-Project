import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Upload as UploadIcon, FileImage, FileText, Zap, CheckCircle, AlertTriangle, Download, Clock } from "lucide-react";
import { Link } from "react-router-dom";
import { useUpload } from "@/context/UploadContext";
import ImageCropper from "@/components/ImageCropper";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import * as pdfjsLib from 'pdfjs-dist';

// Setup PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.mjs`;

// Helper function to get file icon based on type
const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    if (['png', 'jpg', 'jpeg', 'svg'].includes(extension || '')) {
        return <FileImage className="h-5 w-5 text-primary mr-3 flex-shrink-0" />;
    }
    return <FileText className="h-5 w-5 text-primary mr-3 flex-shrink-0" />;
};


const Upload = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [isTextFading, setIsTextFading] = useState(false);

  const [imageToCrop, setImageToCrop] = useState<string | null>(null);
  const [originalFile, setOriginalFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const {
    uploadQueue,
    isProcessing,
    handleFileUpload,
    addPdfToQueue,
    updateConversionProgress,
    removeQueueItem,
    progress,
    currentMessageIndex,
    analysisMessages
  } = useUpload();

  const [displayedMessage, setDisplayedMessage] = useState(analysisMessages[0]);
  const currentlyProcessingFile = uploadQueue.find(item => item.status === 'processing');

  useEffect(() => {
    if (!currentlyProcessingFile) return;
    if (analysisMessages[currentMessageIndex] !== displayedMessage) {
        setIsTextFading(true);
        setTimeout(() => {
            setDisplayedMessage(analysisMessages[currentMessageIndex]);
            setIsTextFading(false);
        }, 400);
    }
  }, [currentMessageIndex, currentlyProcessingFile, displayedMessage, analysisMessages]);

  const handlePdfFile = async (file: File) => {
    const itemId = addPdfToQueue(file);
    const loadingTask = pdfjsLib.getDocument(URL.createObjectURL(file));
    const pdf = await loadingTask.promise;
    const imageFiles: File[] = [];
    const baseName = getBaseFileName(file.name);

    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const viewport = page.getViewport({ scale: 1.5 });
      const canvas = document.createElement('canvas');
      const context = canvas.getContext('2d');
      canvas.height = viewport.height;
      canvas.width = viewport.width;

      if (context) {
        const renderContext = {
          canvasContext: context,
          viewport: viewport,
          canvas: canvas,
        };
        await page.render(renderContext).promise;
        const blob = await new Promise<Blob | null>(resolve => canvas.toBlob(resolve, 'image/png'));

        if (blob) {
          const imageName = `${baseName}_page_${i}.png`;
          const imageFile = new File([blob], imageName, { type: 'image/png' });
          imageFiles.push(imageFile);
        }
      }
      updateConversionProgress(itemId, (i / pdf.numPages) * 100);
    }

    handleFileUpload(imageFiles);
    removeQueueItem(itemId);
  };

  const processFiles = (files: File[]) => {
      const imageFiles = files.filter(file => file.type.startsWith('image/'));
      const pdfFiles = files.filter(file => file.type === 'application/pdf');
      const otherFiles = files.filter(file => !file.type.startsWith('image/') && file.type !== 'application/pdf');

      if (otherFiles.length > 0) {
          handleFileUpload(otherFiles);
      }

      pdfFiles.forEach(handlePdfFile);

      if (imageFiles.length > 0) {
          const file = imageFiles[0];
          setOriginalFile(file);
          setImageToCrop(URL.createObjectURL(file));
      }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  // --- MODIFIED: Handles multi-file drop logic ---
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const droppedFiles = Array.from(e.dataTransfer.files);

    if (droppedFiles.length === 0) {
        return;
    }

    const pdfFiles = droppedFiles.filter(file => file.type === 'application/pdf');
    const imageFiles = droppedFiles.filter(file => file.type.startsWith('image/'));

    if (pdfFiles.length > 0) {
      pdfFiles.forEach(handlePdfFile);
    }

    if (droppedFiles.length > 1 && imageFiles.length > 0) {
        // If multiple files are dropped, upload them all directly
        handleFileUpload(imageFiles);
    } else if (imageFiles.length === 1) {
        // If a single file is dropped, use the existing process that may crop it
        processFiles(imageFiles);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const mode = e.currentTarget.getAttribute('data-upload-mode') as 'crop' | 'direct' || 'crop';
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      const pdfFiles = selectedFiles.filter(file => file.type === 'application/pdf');
      const imageFiles = selectedFiles.filter(file => file.type.startsWith('image/'));

      if (pdfFiles.length > 0) {
        pdfFiles.forEach(handlePdfFile);
      }

      if (mode === 'crop' && imageFiles.length > 0) {
          processFiles(imageFiles);
      } else if (imageFiles.length > 0) {
          handleFileUpload(imageFiles);
      }
      e.target.value = ''; // Reset file input
    }
  };

  const handleBrowseClick = (mode: 'crop' | 'direct') => {
    if (fileInputRef.current) {
        fileInputRef.current.setAttribute('data-upload-mode', mode);
        fileInputRef.current.click();
    }
  };

  const handleCropComplete = (croppedFile: File) => {
      handleFileUpload([croppedFile]);
      handleCropClose();
  };

  const handleCropClose = () => {
      if (imageToCrop) {
          URL.revokeObjectURL(imageToCrop);
      }
      setImageToCrop(null);
      setOriginalFile(null);
  };

  const getBaseFileName = (fileName: string) => {
    return fileName.substring(0, fileName.lastIndexOf('.')) || fileName;
  }

  return (
    <div className="min-h-screen bg-gradient-mesh py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Section */}
        <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Upload Your P&IDs</h1>
            <p className="text-xl text-muted-foreground">
                {imageToCrop ? "Fine-tune your image before processing" : "Drag, drop, or browse to add files for analysis"}
            </p>
        </div>

        {/* --- Conditional Uploader/Cropper --- */}
        {imageToCrop && originalFile ? (
            <ImageCropper
                imageSrc={imageToCrop}
                originalFile={originalFile}
                onCropComplete={handleCropComplete}
                onClose={handleCropClose}
            />
        ) : (
             <Card className="p-8 mb-8">
                <div
                    className={`border-2 border-dashed rounded-xl p-12 text-center transition-all duration-300 ${
                    isDragging
                        ? "border-primary bg-primary/5 scale-105"
                        : "border-border hover:border-primary/50"
                    }`}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                >
                    <div className="space-y-6">
                        <div className={`mx-auto w-24 h-24 rounded-full bg-gradient-primary flex items-center justify-center ${isDragging || isProcessing ? 'animate-glow-pulse' : ''}`}>
                            <UploadIcon className="h-12 w-12 text-primary-foreground" />
                        </div>
                        <div>
                            <h3 className="text-xl font-semibold mb-2">
                                {isDragging ? "Drop files here" : "Add P&ID Files to Queue"}
                            </h3>
                            <p className="text-muted-foreground mb-4">
                                Supports PDF, PNG, JPG, and other formats
                            </p>
                            {/* --- MODIFIED: Removed disabled prop --- */}
                            <input
                                type="file"
                                ref={fileInputRef}
                                accept=".pdf,.png,.jpg,.jpeg,.dwg,.svg"
                                onChange={handleFileSelect}
                                className="hidden"
                                id="file-upload"
                                multiple
                            />
                            {/* --- MODIFIED: Removed disabled prop --- */}
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <Button variant="gradient" size="lg">
                                        Browse Files
                                    </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent>
                                    <DropdownMenuItem onSelect={() => handleBrowseClick('crop')}>
                                        Crop and Upload Image
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onSelect={() => handleBrowseClick('direct')}>
                                        Upload Directly
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        </div>
                        <div className="flex justify-center space-x-4 text-sm text-muted-foreground">
                            <div className="flex items-center"><FileText className="h-4 w-4 mr-1" />PDF</div>
                            <div className="flex items-center"><FileImage className="h-4 w-4 mr-1" />Images</div>
                            {/* <div className="flex items-center"><FileText className="h-4 w-4 mr-1" />CAD</div> */}
                        </div>
                    </div>
                </div>
            </Card>
        )}

        {/* File Queue Display Section */}
        {uploadQueue.length > 0 && (
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-4">Processing Queue</h2>
            <div className="space-y-4">
              {uploadQueue.map((item) => {
                const { file, status, result, error } = item;
                const isThisItemProcessing = status === 'processing';
                const isThisItemConverting = status === 'converting';

                return (
                    <div key={item.id} className="border bg-muted/30 rounded-lg p-4 transition-all">
                        <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center min-w-0">
                                {getFileIcon(file.name)}
                                <div className="flex flex-col min-w-0">
                                    <span className="font-medium truncate">{file.name}</span>
                                    <span className="text-sm text-muted-foreground">
                                        ({(file.size / 1024 / 1024).toFixed(2)} MB)
                                    </span>
                                </div>
                            </div>
                            {status === 'completed' && <CheckCircle className="h-6 w-6 text-green-500 flex-shrink-0" />}
                            {status === 'queued' && <Clock className="h-6 w-6 text-amber-500 flex-shrink-0" />}
                            {status === 'error' && <AlertTriangle className="h-6 w-6 text-destructive flex-shrink-0" />}
                            {isThisItemProcessing && <Zap className="h-6 w-6 text-primary animate-pulse flex-shrink-0" />}
                            {isThisItemConverting && <Zap className="h-6 w-6 text-primary animate-pulse flex-shrink-0" />}
                        </div>
                        {isThisItemProcessing && (
                            <div className="space-y-3 pt-2">
                                <Progress value={progress} className="w-full" />
                                <p className={`text-center text-muted-foreground text-sm min-h-[20px] transition-opacity duration-300 ease-in-out ${isTextFading ? 'opacity-0' : 'opacity-100'}`}>
                                    {displayedMessage}
                                </p>
                            </div>
                        )}
                        {isThisItemConverting && (
                            <div className="space-y-3 pt-2">
                                <Progress value={item.conversionProgress} className="w-full" />
                                <p className="text-center text-muted-foreground text-sm min-h-[20px]">
                                    Converting PDF to images...
                                </p>
                            </div>
                        )}
                        {status === 'error' && (
                            <div className="flex items-start bg-destructive/10 text-destructive p-3 rounded-md">
                                <AlertTriangle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                                <p className="text-sm font-medium">{error || "An unknown error occurred."}</p>
                            </div>
                        )}
                        {status === 'completed' && result && (
                            <div className="space-y-4 pt-2">
                                <div className="border rounded-lg overflow-hidden">
                                    <img src={result.annotatedImage || ''} alt={`Annotated P&ID for ${file.name}`} className="w-full h-auto" />
                                </div>
                                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                                    <a href={result.excelDataUrl || ''} download={`predictions_${getBaseFileName(file.name)}.xlsx`}>
                                        <Button size="lg" className="w-full sm:w-auto">
                                            <Download className="mr-2 h-5 w-5" />
                                            Download Excel
                                        </Button>
                                    </a>
                                    <Button asChild variant="outline" size="lg" className="w-full sm:w-auto">
                                        <Link to="/results">
                                            View All Results
                                            <Zap className="ml-2 h-5 w-5" />
                                        </Link>
                                    </Button>
                                </div>
                            </div>
                        )}
                    </div>
                );
              })}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
};

export default Upload;