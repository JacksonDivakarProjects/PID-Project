/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useEffect } from 'react';
import { useUpload } from '../context/UploadContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
    Eye,
    FileText,
    CheckCircle,
    Zap,
    Clock,
    AlertTriangle,
    ArrowRight,
    Sparkles,
    Loader2,
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import ImageViewer from '@/components/ImageViewer';
import * as XLSX from 'xlsx';

// Helper to convert base64 to Blob, handling potential data URI prefixes
const base64ToBlob = (base64: string, mimeType: string): Blob => {
    // Strip prefix if it exists
    const base64Data = base64.split(',')[1] || base64;
    
    try {
        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        return new Blob([byteArray], { type: mimeType });
    } catch (e) {
        console.error("Failed to decode base64 string:", e);
        throw new Error("The provided base64 string is not valid.");
    }
};


const Results = () => {
    const { uploadQueue, updateAnalysisResult, updateNeedsReview, enhancingIds, setEnhancingIds, analysisQueue, addToAnalysisQueue, removeFromAnalysisQueue } = useUpload();
    const [viewingImage, setViewingImage] = useState<string | null>(null);
    const [apiError, setApiError] = useState<string | null>(null);
    const navigate = useNavigate();

    const getBaseFileName = (fileName: string) => {
        if (!fileName) return '';
        return fileName.substring(0, fileName.lastIndexOf('.')) || fileName;
    };

    const handleNavigateToExport = (item: any) => {
        if (!item.result?.excelDataUrl) return;
        navigate('/export', {
            state: {
                excelDataUrl: item.result.excelDataUrl,
                originalFileName: item.file.name,
            },
        });
    };

    useEffect(() => {
        const processQueue = async () => {
            if (analysisQueue.length > 0 && enhancingIds.length === 0) {
                const itemId = analysisQueue[0];
                const item = uploadQueue.find(i => i.id === itemId);
                if (item) {
                    await handleAnalysis(item);
                }
            }
        };
        processQueue();
    }, [analysisQueue, enhancingIds, uploadQueue]);

    const handleAnalysis = async (item: any) => {
        if (!item.result?.excelDataUrl || !item.file || !item.result?.annotatedImage) {
            setApiError("Cannot generate report: Missing original image, annotated image, or initial Excel file.");
            removeFromAnalysisQueue(item.id);
            return;
        }

        setEnhancingIds(prev => [...prev, item.id]);
        setApiError(null);

        try {
            // Step 1: Hit the /excel_ocr/process-excel-with-image endpoint
            const excelResponse = await fetch(item.result.excelDataUrl);
            const excelBlob = await excelResponse.blob();

            const annotatedImageResponse = await fetch(item.result.annotatedImage);
            const annotatedImageBlob = await annotatedImageResponse.blob();

            const formData1 = new FormData();
            formData1.append('image_file', annotatedImageBlob, `annotated_${item.file.name}`);
            formData1.append('excel_file', excelBlob, `predictions_${getBaseFileName(item.file.name)}.xlsx`);

            const ocrResponse = await fetch('http://localhost:8000/excel_ocr/process-excel-with-image', {
                method: 'POST',
                body: formData1,
            });

            if (!ocrResponse.ok) {
                const errorData = await ocrResponse.json().catch(() => ({ detail: 'Failed to process the OCR enhancement.' }));
                throw new Error(errorData.detail || 'Server failed during OCR enhancement step.');
            }
            
            const ocrData = await ocrResponse.json();
            const processedExcelBase64 = ocrData.file_base64;

            const processedExcelBlob = base64ToBlob(processedExcelBase64, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            
            const arrayBuffer = await processedExcelBlob.arrayBuffer();
            const workbook = XLSX.read(arrayBuffer, { type: 'array' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet);

            const needsReview = jsonData.some(
                (row: any) => !row.extracted_text || String(row.extracted_text).trim().toLowerCase() === 'nothing'
            );

            if (needsReview) {
                updateNeedsReview(item.id, true);
            }

            // Step 2: Hit the /pid-analysis/analyze endpoint
            const formData2 = new FormData();
            formData2.append('image_file', item.file, item.file.name);
            formData2.append('excel_file', processedExcelBlob, `processed_predictions_${getBaseFileName(item.file.name)}.xlsx`);

            const apiResponse = await fetch('http://localhost:8000/pid-analysis/analyze', {
                method: 'POST',
                body: formData2,
            });

            if (!apiResponse.ok) {
                const errorData = await apiResponse.json().catch(() => ({ detail: 'An unknown server error occurred.' }));
                throw new Error(errorData.detail || 'Failed to process the files on the server.');
            }

            const responseData = await apiResponse.json();
            
            updateAnalysisResult(item.id, {
                dexpiXml: responseData.dexpi_xml_base64,
                statisticsExcel: responseData.statistics_excel_base64,
                industrialJson: responseData.industrial_json_base64,
            });

        } catch (err: any) {
            console.error("Analysis failed:", err);
            setApiError(err.message || "An unexpected error occurred while generating the report.");
        } finally {
            setEnhancingIds(prev => prev.filter(id => id !== item.id));
            removeFromAnalysisQueue(item.id);
        }
    };

    return (
        <>
            <div className="min-h-screen bg-gradient-mesh py-20">
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-12">
                        <h1 className="text-4xl font-bold mb-4">Upload History & Status</h1>
                        <p className="text-xl text-muted-foreground">
                            Review the status and results of all your uploaded files.
                        </p>
                    </div>

                    {apiError && (
                        <Card className="p-4 mb-6 bg-destructive/10 text-destructive border-destructive">
                            <div className="flex items-center">
                                <AlertTriangle className="h-5 w-5 mr-3 flex-shrink-0" />
                                <p>{apiError}</p>
                            </div>
                        </Card>
                    )}

                    <div className="space-y-8">
                        {uploadQueue.length > 0 ? (
                            [...uploadQueue].reverse().map((item) => {
                                const isEnhanced = item.result?.isEnhanced;
                                const isProcessing = enhancingIds.includes(item.id) || analysisQueue.includes(item.id);

                                return (
                                <Card key={item.id} className="p-6 transition-all">
                                    <div className="flex items-center mb-4 border-b pb-4">
                                        <FileText className="h-6 w-6 text-primary mr-3 flex-shrink-0" />
                                        <h2 className="text-xl font-semibold truncate" title={item.file.name}>
                                            {item.file.name}
                                        </h2>
                                    </div>

                                    {item.status === 'completed' && item.result && (
                                        <div className="text-center">
                                            <div className="flex items-center justify-center text-green-500 mb-6">
                                                <CheckCircle className="h-5 w-5 mr-2" />
                                                <p className="font-medium">Analysis Completed</p>
                                            </div>
                                            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 flex-wrap">
                                                {item.result.annotatedImage && (
                                                    <Button size="lg" variant="outline" onClick={() => setViewingImage(item.result!.annotatedImage)}>
                                                        <Eye className="mr-2 h-5 w-5" />
                                                        View Annotated Image
                                                    </Button>
                                                )}
                                                
                                                {item.result.excelDataUrl && (
                                                    <Button size="lg" variant="outline" onClick={() => handleNavigateToExport(item)}>
                                                        <ArrowRight className="mr-2 h-5 w-5" />
                                                        Export Data
                                                    </Button>
                                                )}

                                                {item.result.excelDataUrl && (
                                                    isEnhanced ? (
                                                        <Button size="lg" disabled>
                                                            <CheckCircle className="mr-2 h-5 w-5" />
                                                            Analysis Complete
                                                        </Button>
                                                    ) : (
                                                        <Button
                                                            size="lg"
                                                            onClick={() => addToAnalysisQueue(item.id)}
                                                            disabled={isProcessing}
                                                        >
                                                            {isProcessing ? (
                                                                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                                                            ) : (
                                                                <Sparkles className="mr-2 h-5 w-5" />
                                                            )}
                                                            {isProcessing ? 'Analyzing...' : 'Analyze Data'}
                                                        </Button>
                                                    )
                                                )}
                                            </div>
                                        </div>
                                    )}

                                    {item.status === 'processing' && ( <div className="flex items-center justify-center p-4"> <Zap className="h-6 w-6 text-primary mr-3 animate-pulse" /> <p className="text-lg font-medium text-muted-foreground">Analysis in Progress...</p> </div> )}
                                    {item.status === 'queued' && ( <div className="flex items-center justify-center p-4"> <Clock className="h-6 w-6 text-amber-500 mr-3" /> <p className="text-lg font-medium text-muted-foreground">Queued for Processing</p> </div> )}
                                    {item.status === 'error' && ( <div className="flex items-center bg-destructive/10 text-destructive p-4 rounded-md"> <AlertTriangle className="h-6 w-6 mr-3 flex-shrink-0" /> <div> <h3 className="font-semibold">Processing Failed</h3> <p className="text-sm">{item.error || "An unknown error occurred."}</p> </div> </div> )}
                                </Card>
                            )})
                        ) : (
                            <Card className="p-8">
                                <p className="text-muted-foreground text-center">
                                    No files have been uploaded yet. Please <Link to="/upload" className="text-primary hover:underline">upload a P&ID</Link> to get started.
                                </p>
                            </Card>
                        )}
                    </div>
                </div>
            </div>

            {viewingImage && (
                <ImageViewer
                    imageUrl={viewingImage}
                    onClose={() => setViewingImage(null)}
                />
            )}
        </>
    );
};

export default Results;