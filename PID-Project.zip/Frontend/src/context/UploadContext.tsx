/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { createContext, useState, useContext, ReactNode, useEffect, useRef } from 'react';
import * as XLSX from 'xlsx';
import { v4 as uuidv4 } from 'uuid';

// --- ANALYSIS MESSAGES ---
const ANALYSIS_MESSAGES = [
    "Calibrating neural pathways...",
    "Decoding engineering schematics...",
    "Initializing cognitive processors...",
    "Segmenting pipelines from background noise...",
    "Identifying and classifying all components...",
    "Extracting labels with Optical Character Recognition...",
    "Tracing process flow connections...",
    "Building topological map of the system...",
    "Cross-referencing component databases...",
    "Finalizing structured data output...",
    "Almost there, just polishing the results...",
];

// --- INTERFACES ---
export interface ComponentData {
    [key: string]: any;
}

export interface PipeData {
    [key: string]: any;
}

export interface AnalysisResult {
    annotatedImage: string | null;
    excelDataUrl: string | null;
    originalFileName: string;
    componentData: ComponentData[];
    pipeData?: PipeData[];
    isEnhanced?: boolean;
    needsReview?: boolean;
    pipeNeedsReview?: boolean;
    dexpiXml?: string;
    statisticsExcel?: string;
    industrialJson?: string;
}

export interface UploadQueueItem {
    id: string;
    file: File;
    status: 'queued' | 'processing' | 'completed' | 'error' | 'converting';
    result?: AnalysisResult;
    error?: string;
    conversionProgress?: number;
}

interface UploadContextType {
    uploadQueue: UploadQueueItem[];
    isProcessing: boolean;
    handleFileUpload: (selectedFiles: File[]) => void;
    addPdfToQueue: (file: File) => string;
    updateConversionProgress: (itemId: string, progress: number) => void;
    removeQueueItem: (itemId: string) => void;
    updateAnalysisResult: (
        itemId: string,
        analysisData: {
            dexpiXml: string;
            statisticsExcel: string;
            industrialJson: string;
        }
    ) => void;
    progress: number;
    currentMessageIndex: number;
    analysisMessages: string[];
    updateNeedsReview: (itemId: string, needsReview: boolean) => void;
    enhancingIds: string[];
    setEnhancingIds: React.Dispatch<React.SetStateAction<string[]>>;
    analysisQueue: string[];
    addToAnalysisQueue: (itemId: string) => void;
    removeFromAnalysisQueue: (itemId: string) => void;
}


const UploadContext = createContext<UploadContextType | undefined>(undefined);

export const UploadProvider = ({ children }: { children: ReactNode }) => {
    const [uploadQueue, setUploadQueue] = useState<UploadQueueItem[]>([]);
    const [progress, setProgress] = useState(0);
    const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
    const [enhancingIds, setEnhancingIds] = useState<string[]>([]);
    const [analysisQueue, setAnalysisQueue] = useState<string[]>([]);

    const isProcessing = uploadQueue.some(item => item.status === 'processing');
    const currentlyProcessingItem = uploadQueue.find(item => item.status === 'processing');

    const progressIntervalRef = useRef<number | null>(null);
    const messageIntervalRef = useRef<number | null>(null);

    const handleFileUpload = (selectedFiles: File[]) => {
        const newQueueItems: UploadQueueItem[] = selectedFiles.map(file => ({
            id: uuidv4(),
            file,
            status: 'queued',
        }));
        setUploadQueue(prevQueue => [...prevQueue, ...newQueueItems]);
    };

    const addPdfToQueue = (file: File) => {
        const id = uuidv4();
        const newQueueItem: UploadQueueItem = {
            id,
            file,
            status: 'converting',
            conversionProgress: 0,
        };
        setUploadQueue(prevQueue => [...prevQueue, newQueueItem]);
        return id;
    };

    const updateConversionProgress = (itemId: string, progress: number) => {
        setUploadQueue(prevQueue =>
            prevQueue.map(item =>
                item.id === itemId ? { ...item, conversionProgress: progress } : item
            )
        );
    };

    const removeQueueItem = (itemId: string) => {
        setUploadQueue(prevQueue => prevQueue.filter(item => item.id !== itemId));
    };
    
    const updateAnalysisResult = (
        itemId: string,
        analysisData: {
            dexpiXml: string;
            statisticsExcel: string;
            industrialJson: string;
        }
    ) => {
        setUploadQueue(prevQueue =>
            prevQueue.map(item => {
                if (item.id === itemId && item.result) {
                    const updatedResult: AnalysisResult = {
                        ...item.result,
                        dexpiXml: analysisData.dexpiXml,
                        statisticsExcel: analysisData.statisticsExcel,
                        industrialJson: analysisData.industrialJson,
                        isEnhanced: true, // Mark as enhanced
                    };

                    // Parse statisticsExcel and check for pipe review
                    if (analysisData.statisticsExcel) {
                        try {
                            const excelBytes = atob(analysisData.statisticsExcel);
                            const excelArray = new Uint8Array(excelBytes.length).map((_, i) => excelBytes.charCodeAt(i));
                            const workbook = XLSX.read(excelArray, { type: 'array' });
                            const sheetName = workbook.SheetNames[0]; // Assuming pipe data is in the first sheet
                            const worksheet = workbook.Sheets[sheetName];
                            const jsonData = XLSX.utils.sheet_to_json(worksheet) as PipeData[];
                            updatedResult.pipeData = jsonData;

                            // Check if any pipe has 'low confidence' status
                            const pipeNeedsReview = jsonData.some(
                                (row: any) => row.Status && String(row.Status).trim().toLowerCase() === 'low confidence'
                            );
                            updatedResult.pipeNeedsReview = pipeNeedsReview;
                        } catch (e) {
                            console.error("Failed to parse statistics excel:", e);
                            updatedResult.pipeData = [];
                            updatedResult.pipeNeedsReview = false;
                        }
                    }

                    return { ...item, result: updatedResult };
                }
                return item;
            })
        );
    };

    const updateNeedsReview = (itemId: string, needsReview: boolean) => {
        setUploadQueue(prevQueue =>
            prevQueue.map(item => {
                if (item.id === itemId && item.result) {
                    return {
                        ...item,
                        result: {
                            ...item.result,
                            needsReview,
                        },
                    };
                }
                return item;
            })
        );
    };
    
    const addToAnalysisQueue = (itemId: string) => {
        setAnalysisQueue(prev => [...prev, itemId]);
    };
    
    const removeFromAnalysisQueue = (itemId: string) => {
        setAnalysisQueue(prev => prev.filter(id => id !== itemId));
    };

    // Effect for progress bar and messages
    useEffect(() => {
        const cleanupTimers = () => {
            if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
            if (messageIntervalRef.current) clearInterval(messageIntervalRef.current);
            progressIntervalRef.current = null;
            messageIntervalRef.current = null;
        };

        if (currentlyProcessingItem) {
            setProgress(0);
            setCurrentMessageIndex(0);

            const targetDuration = 2.25 * 60 * 1000;
            const updateInterval = 100;
            const maxProgress = 95;
            const increment = (maxProgress / targetDuration) * updateInterval;

            progressIntervalRef.current = window.setInterval(() => {
                setProgress(p => {
                    if (p >= maxProgress) {
                        if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
                        return maxProgress;
                    }
                    return p + increment;
                });
            }, updateInterval);

            messageIntervalRef.current = window.setInterval(() => {
                setCurrentMessageIndex(i => (i + 1) % ANALYSIS_MESSAGES.length);
            }, 2500);

        } else {
            cleanupTimers();
        }

        return cleanupTimers;
    }, [currentlyProcessingItem]);

    // Queue Processor Effect
    useEffect(() => {
        if (isProcessing) return;

        const nextItem = uploadQueue.find(item => item.status === 'queued');

        if (nextItem) {
            setUploadQueue(prevQueue =>
                prevQueue.map(item =>
                    item.id === nextItem.id ? { ...item, status: 'processing' } : item
                )
            );

            const processItem = async (itemToProcess: UploadQueueItem) => {
                try {
                    const formData = new FormData();
                    formData.append("file", itemToProcess.file);

                    const response = await fetch("http://localhost:8000/img_pred/predict-upload-json/", {
                        method: "POST",
                        body: formData,
                    });

                    if (!response.ok) {
                        const errorData = await response.json().catch(() => ({ detail: 'An unknown server error.' }));
                        throw new Error(errorData.detail || `HTTP error! status: ${response.status}`);
                    }

                    const data = await response.json();

                    const newResult: AnalysisResult = {
                        originalFileName: itemToProcess.file.name,
                        annotatedImage: data.annotated_image_base64 ? `data:image/png;base64,${data.annotated_image_base64}` : null,
                        excelDataUrl: null,
                        componentData: [],
                        isEnhanced: false,
                        needsReview: false, // Initial state is never "needs review"
                    };

                    if (data.excel_data_base64) {
                        const excelBytes = atob(data.excel_data_base64);
                        const excelArray = new Uint8Array(excelBytes.length).map((_, i) => excelBytes.charCodeAt(i));
                        const excelBlob = new Blob([excelArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                        newResult.excelDataUrl = URL.createObjectURL(excelBlob);

                        const workbook = XLSX.read(excelArray, { type: 'array' });
                        const sheetName = workbook.SheetNames[0];
                        const worksheet = workbook.Sheets[sheetName];
                        newResult.componentData = XLSX.utils.sheet_to_json(worksheet) as ComponentData[];
                    }

                    setProgress(100);
                    setUploadQueue(prevQueue =>
                        prevQueue.map(item =>
                            item.id === itemToProcess.id
                                ? { ...item, status: 'completed', result: newResult }
                                : item
                        )
                    );

                } catch (err: any) {
                    console.error("Error processing file:", err);
                    setUploadQueue(prevQueue =>
                        prevQueue.map(item =>
                            item.id === itemToProcess.id
                                ? { ...item, status: 'error', error: err.message }
                                : item
                        )
                    );
                }
            };

            processItem(nextItem);
        }
    }, [uploadQueue, isProcessing]);

    const value = {
        uploadQueue,
        isProcessing,
        handleFileUpload,
        addPdfToQueue,
        updateConversionProgress,
        removeQueueItem,
        updateAnalysisResult,
        progress,
        currentMessageIndex,
        analysisMessages: ANALYSIS_MESSAGES,
        updateNeedsReview,
        enhancingIds,
        setEnhancingIds,
        analysisQueue,
        addToAnalysisQueue,
        removeFromAnalysisQueue,
    };

    return (
        <UploadContext.Provider value={value}>
            {children}
        </UploadContext.Provider>
    );
};

export const useUpload = () => {
    const context = useContext(UploadContext);
    if (context === undefined) {
        throw new Error('useUpload must be used within an UploadProvider');
    }
    return context;
};