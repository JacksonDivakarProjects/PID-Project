import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import Navigation from "@/components/Navigation";
import Home from "@/pages/Home";
import Upload from "@/pages/Upload";
import Results from "@/pages/Results";
import Review from "@/pages/Review";
import Export from "@/pages/Export";
import About from "@/pages/About";
import Playground from "@/pages/Playground";
import NotFound from "@/pages/NotFound";
import { UploadProvider } from "@/context/UploadContext"; // Import the provider
import { AnimatePresence } from "framer-motion";
import AnimatedPage from "@/components/AnimatedPage";

const queryClient = new QueryClient();

const AppRoutes = () => {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route
          path="/"
          element={
            <AnimatedPage>
              <Home />
            </AnimatedPage>
          }
        />
        <Route
          path="/upload"
          element={
            <AnimatedPage>
              <Upload />
            </AnimatedPage>
          }
        />
        <Route
          path="/results"
          element={
            <AnimatedPage>
              <Results />
            </AnimatedPage>
          }
        />
        <Route
          path="/review"
          element={
            <AnimatedPage>
              <Review />
            </AnimatedPage>
          }
        />
        <Route
          path="/export"
          element={
            <AnimatedPage>
              <Export />
            </AnimatedPage>
          }
        />
        <Route
          path="/about"
          element={
            <AnimatedPage>
              <About />
            </AnimatedPage>
          }
        />
        <Route
          path="/play-ground"
          element={
            <AnimatedPage>
              <Playground />
            </AnimatedPage>
          }
        />
        {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
        <Route
          path="*"
          element={
            <AnimatedPage>
              <NotFound />
            </AnimatedPage>
          }
        />
      </Routes>
    </AnimatePresence>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <UploadProvider>
          <BrowserRouter>
            <div className="min-h-screen bg-background">
              <Navigation />
              <AppRoutes />
            </div>
          </BrowserRouter>
        </UploadProvider>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;