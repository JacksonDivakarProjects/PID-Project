from fastapi import APIRouter, UploadFile, File, HTTPException
import pandas as pd
from PIL import Image
import io
import tempfile
import os
from pathlib import Path
from typing import Dict, Any
from datetime import datetime
import base64

router = APIRouter(prefix="/excel_ocr", tags=["EXCEL_OCR"])

# Import your updated service with Gemini 2.5
from ocr_process.services.pnid_img_text_process import (
    extract_components_from_full_image,
    get_mime_type
)

def excel_to_base64(df: pd.DataFrame, sheet_name: str = 'OCR_Results') -> str:
    """
    Convert DataFrame to Excel format and encode as base64
    
    Args:
        df: DataFrame to convert
        sheet_name: Name of the Excel sheet
        
    Returns:
        Base64 encoded Excel file
    """
    excel_buffer = io.BytesIO()
    with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name=sheet_name, index=False)
    
    excel_buffer.seek(0)
    excel_base64 = base64.b64encode(excel_buffer.getvalue()).decode('utf-8')
    return excel_base64

def process_full_image_with_components(df: pd.DataFrame, image_path: str) -> pd.DataFrame:
    """
    Process full image with component data using Gemini 2.5
    
    Args:
        df: DataFrame with component information
        image_path: Path to the source image
        
    Returns:
        Updated DataFrame with extracted text for each component
    """
    # Prepare component data for Gemini 2.5
    components_info = []
    for idx, row in df.iterrows():
        component_info = {
            'index': idx,
            'component_name': str(row.get('Component Name', '')),
            'x': float(row.get('x', 0)) if 'x' in row else None,
            'y': float(row.get('y', 0)) if 'y' in row else None,
            'width': float(row.get('width', 0)) if 'width' in row else None,
            'height': float(row.get('height', 0)) if 'height' in row else None,
            'additional_info': {k: v for k, v in row.items() if k not in ['x', 'y', 'width', 'height', 'Component Name']}
        }
        components_info.append(component_info)
    
    # Send full image and component data to Gemini 2.5
    try:
        extracted_results = extract_components_from_full_image(image_path, components_info)
        
        # Initialize new columns
        df['extracted_text'] = ''
        df['ocr_status'] = ''
        df['processing_timestamp'] = datetime.now().isoformat()
        df['vlm_model'] = 'gemini-2.5-flash'
        
        # Update DataFrame with results
        for result in extracted_results:
            idx = result.get('index')
            if idx is not None and idx < len(df):
                df.at[idx, 'extracted_text'] = result.get('text', 'NO_TEXT_FOUND')
                df.at[idx, 'ocr_status'] = result.get('status', 'PROCESSED')
        
        return df
        
    except Exception as e:
        # If Gemini 2.5 processing fails, mark all as failed
        df['extracted_text'] = f'ERROR: {str(e)}'
        df['ocr_status'] = 'FAILED'
        df['processing_timestamp'] = datetime.now().isoformat()
        df['vlm_model'] = 'gemini-2.5-flash'
        return df

@router.post("/process-excel-with-image")
async def process_excel_image_ocr(
    excel_file: UploadFile = File(..., description="Excel file with component data"),
    image_file: UploadFile = File(..., description="Source image for OCR processing")
):
    """
    Process Excel file with component data and extract text from full image using Gemini 2.5
    Returns Excel file as base64 encoded string
    
    Args:
        excel_file: Excel file with component information
        image_file: Source image file (jpg, jpeg, png, gif, bmp, webp)
        
    Returns:
        JSON response with base64 encoded Excel file containing OCR results
    """
    
    # Validate Excel file type
    if not excel_file.filename.lower().endswith(('.xlsx', '.xls')):
        raise HTTPException(
            status_code=400, 
            detail="Excel file must be .xlsx or .xls format"
        )
    
    # Validate image file type
    allowed_extensions = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'}
    image_extension = Path(image_file.filename).suffix.lower()
    
    if image_extension not in allowed_extensions:
        raise HTTPException(
            status_code=400, 
            detail=f"Unsupported image type. Allowed types: {', '.join(allowed_extensions)}"
        )
    
    temp_excel_path = None
    temp_image_path = None
    
    try:
        # Save uploaded Excel file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as temp_excel:
            excel_content = await excel_file.read()
            temp_excel.write(excel_content)
            temp_excel_path = temp_excel.name
        
        # Save uploaded image file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=image_extension) as temp_image:
            image_content = await image_file.read()
            temp_image.write(image_content)
            temp_image_path = temp_image.name
        
        # Load Excel data
        try:
            df = pd.read_excel(temp_excel_path)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Error reading Excel file: {str(e)}")
        
        # Validate that DataFrame is not empty
        if df.empty:
            raise HTTPException(
                status_code=400, 
                detail="Excel file is empty"
            )
        
        # Process full image with component data using Gemini 2.5
        updated_df = process_full_image_with_components(df, temp_image_path)
        
        # Generate output filename
        original_name = Path(excel_file.filename).stem
        excel_filename = f"{original_name}_gemini_ocr_results.xlsx"
        
        # Convert to base64
        excel_base64 = excel_to_base64(updated_df)
        
        # Calculate statistics
        success_count = len(updated_df[updated_df['ocr_status'] == 'PROCESSED'])
        failed_count = len(updated_df[updated_df['ocr_status'] == 'FAILED'])
        
        # Prepare response data
        response_data = {
            "status": "success",
            "processed_count": len(updated_df),
            "success_count": success_count,
            "failed_count": failed_count,
            "filename": excel_filename,
            "file_base64": excel_base64,
            "mime_type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "processing_info": {
                "original_filename": excel_file.filename,
                "image_filename": image_file.filename,
                "processing_timestamp": datetime.now().isoformat(),
                "processing_method": "gemini_2.5_flash_vlm",
                "vlm_model": "gemini-2.5-flash"
            }
        }
        
        return response_data
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error during processing: {str(e)}"
        )
    finally:
        # Clean up temporary files
        if temp_excel_path and os.path.exists(temp_excel_path):
            os.unlink(temp_excel_path)
        if temp_image_path and os.path.exists(temp_image_path):
            os.unlink(temp_image_path)

@router.get("/processing-info")
async def get_processing_info() -> Dict[str, Any]:
    """Get information about the Gemini 2.5 OCR processing"""
    return {
        "description": "OCR processing using Gemini 2.5 Flash with full image and component data",
        "vlm_model": "gemini-2.5-flash",
        "supported_image_formats": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp"],
        "excel_requirements": {
            "format": ".xlsx or .xls",
            "required_columns": "No specific columns required - all data will be preserved",
            "optional_columns": ["Component Name", "x", "y", "width", "height"],
            "description": "Any additional columns will be preserved in output"
        },
        "processing_method": {
            "type": "gemini_2.5_full_image_vlm",
            "description": "Sends entire image and component data to Gemini 2.5 for batch processing",
            "advantages": ["No cropping required", "Context-aware OCR", "JSON structured response", "High accuracy multimodal understanding"]
        },
        "output_format": {
            "type": "base64_excel",
            "additional_columns": ["extracted_text", "ocr_status", "processing_timestamp", "vlm_model"],
            "description": "Original data plus OCR results in base64 encoded Excel file"
        },
        "gemini_features": {
            "model": "gemini-2.5-flash",
            "multimodal": "Built-in image understanding capabilities",
            "json_mode": "Structured JSON responses",
            "context_window": "Large context for comprehensive image analysis"
        }
    }
