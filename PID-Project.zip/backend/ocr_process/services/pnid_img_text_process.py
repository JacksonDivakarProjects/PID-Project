from fastapi import HTTPException
import base64
import json
import os
from pathlib import Path
from typing import List, Dict, Any
from PIL import Image
from google.genai import types

from config.settings import client, MODEL_NAME




def encode_image_to_base64(image_path: str) -> str:
    """Encode image file to base64 string"""
    try:
        with open(image_path, "rb") as img:
            return base64.b64encode(img.read()).decode("utf-8")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error encoding image: {str(e)}")

def extract_components_from_full_image(image_path: str, components_info: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Extract text for all components from full image using Gemini 2.5
    
    Args:
        image_path: Path to the image file
        components_info: List of component information dictionaries
        
    Returns:
        List of dictionaries with extraction results for each component
    """
    try:
        # Load image using PIL
        image = Image.open(image_path)
        
        # Prepare component list for the prompt
        components_text = ""
        for i, comp in enumerate(components_info):
            comp_name = comp.get('component_name', 'Unknown')
            x = comp.get('x')
            y = comp.get('y')
            
            if x is not None and y is not None:
                components_text += f"{i+1}. Component: {comp_name} (at x:{x}, y:{y})\n"
            else:
                components_text += f"{i+1}. Component: {comp_name}\n"
        
        prompt = f"""
You are an expert in reading P&ID diagrams and technical drawings.

Input: A P&ID image with multiple components that need text extraction.

Components to identify:
{components_text}

Your task:
1. Analyze the entire P&ID image
2. For each component listed above, find and extract any visible tag/label/ID text
3. Tags are typically short codes like "OP-11854", "XV-203", "LT-101", "V-101", etc.
4. If coordinates are provided, focus on those areas but also consider nearby labels
5. Ignore surrounding text, notes, descriptions, or line numbers

Output format:
Return a JSON array with one object per component:
[
  {{"index": 0, "text": "OP-11854", "status": "PROCESSED"}},
  {{"index": 1, "text": "XV-203", "status": "PROCESSED"}},
  {{"index": 2, "text": "nothing", "status": "PROCESSED"}}
]

If no text is found for a component, use "nothing" as the text value.
Always return valid JSON format.
"""

        # Configure response to be JSON
        config = types.GenerateContentConfig(
            response_mime_type="application/json"
        )

        # Make API call to Gemini 2.5
        response = client.models.generate_content(
            model=MODEL_NAME,
            contents=[prompt, image],
            config=config
        )
        
        # Parse the response
        response_content = response.text.strip()
        
        # Try to parse JSON from the response
        try:
            results = json.loads(response_content)
            
            # Ensure results is a list
            if not isinstance(results, list):
                raise ValueError("Response is not a list")
                
        except (json.JSONDecodeError, ValueError):
            # If JSON parsing fails, create default results
            results = []
            for i, comp in enumerate(components_info):
                results.append({
                    "index": i,
                    "text": "JSON_PARSE_ERROR",
                    "status": "FAILED"
                })
        
        # Ensure we have results for all components
        while len(results) < len(components_info):
            results.append({
                "index": len(results),
                "text": "NO_RESULT",
                "status": "FAILED"
            })
        
        return results[:len(components_info)]  # Trim to exact number of components
        
    except Exception as e:
        # Return error results for all components
        results = []
        for i, comp in enumerate(components_info):
            results.append({
                "index": i,
                "text": f"ERROR: {str(e)[:50]}",
                "status": "FAILED"
            })
        return results

def get_mime_type(filename: str) -> str:
    """Get MIME type based on file extension"""
    extension = Path(filename).suffix.lower()
    mime_types = {
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.png': 'image/png',
        '.gif': 'image/gif',
        '.bmp': 'image/bmp',
        '.webp': 'image/webp'
    }
    return mime_types.get(extension, 'image/jpeg')
