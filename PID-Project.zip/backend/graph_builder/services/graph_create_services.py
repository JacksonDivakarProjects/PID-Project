import cv2
import pandas as pd
import numpy as np
import uuid
from scipy.spatial import KDTree

def load_components_from_excel(excel_path):
    df = pd.read_excel(excel_path)
    
    # Clean the DataFrame of NaN values
    df = df.fillna(0)  # Replace NaN with 0, or you can use df.dropna() to remove rows with NaN
    
    nodes = []
    comp_centers = []

    for _, row in df.iterrows():
        # Ensure all values are valid numbers
        x = float(row["x"]) if pd.notna(row["x"]) else 0.0
        y = float(row["y"]) if pd.notna(row["y"]) else 0.0
        w = float(row["width"]) if pd.notna(row["width"]) else 0.0
        h = float(row["height"]) if pd.notna(row["height"]) else 0.0
        
        # Skip if any critical values are invalid - FIXED
        if np.isnan([x, y, w, h]).any() or np.isinf([x, y, w, h]).any():
            continue
            
        bbox = [x, y, x + w, y + h]

        node_id = str(uuid.uuid4())
        
        # Handle component name and class safely
        component_name = row["Component Name"] if pd.notna(row["Component Name"]) else "Unknown"
        component_class = str(row["class"]) if pd.notna(row["class"]) else "0"
        extracted_text = str(row["extracted_text"]) if pd.notna(row["extracted_text"]) else ""
        
        node = {
            "id": node_id,
            "label": component_name,
            "type": component_class,
            "bbox": bbox,
            "component_id": extracted_text
        }
        nodes.append(node)

        # Store center for KDTree lookup
        center = ((x + x + w) / 2, (y + y + h) / 2)
        
        # Validate center coordinates - FIXED
        if not (np.isnan([center[0], center[1]]).any() or np.isinf([center[0], center[1]]).any()):
            comp_centers.append((center, node_id))

    return nodes, comp_centers

def detect_pipes(image_path):
    try:
        img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        
        if img is None:
            print(f"Warning: Could not load image from {image_path}")
            return []
            
        edges = cv2.Canny(img, 50, 150, apertureSize=3)
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=80,
                                minLineLength=40, maxLineGap=15)

        pipes = []
        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                
                # Validate line coordinates - FIXED
                if not (np.isnan([x1, y1, x2, y2]).any() or np.isinf([x1, y1, x2, y2]).any()):
                    pipes.append(((int(x1), int(y1)), (int(x2), int(y2))))
                    
        return pipes
    except Exception as e:
        print(f"Error in detect_pipes: {e}")
        return []

def build_graph_with_kdtree(pipes, comp_centers):
    if not comp_centers:
        print("Warning: No valid component centers found")
        return []
        
    try:
        centers = np.array([c[0] for c in comp_centers])
        ids = [c[1] for c in comp_centers]
        
        # Check if we have valid centers
        if len(centers) == 0:
            return []
            
        tree = KDTree(centers)
        edges = []

        for (p1, p2) in pipes:
            try:
                # Validate pipe coordinates - FIXED
                pipe_coords = [p1[0], p1[1], p2[0], p2[1]]
                if np.isnan(pipe_coords).any() or np.isinf(pipe_coords).any():
                    continue
                    
                _, idx1 = tree.query(p1)
                _, idx2 = tree.query(p2)

                # Validate indices
                if idx1 >= len(ids) or idx2 >= len(ids):
                    continue
                    
                comp1 = ids[idx1]
                comp2 = ids[idx2]

                if comp1 != comp2:
                    length = np.linalg.norm(np.array(p1) - np.array(p2))
                    
                    # Validate length calculation
                    if np.isnan(length) or np.isinf(length):
                        length = 0.0
                        
                    edge = {
                        "from": comp1,
                        "to": comp2,
                        "length": float(length)
                    }
                    
                    # Check for duplicate edges
                    if not any(((e["from"] == edge["from"] and e["to"] == edge["to"]) or
                                (e["from"] == edge["to"] and e["to"] == edge["from"]))
                               for e in edges):
                        edges.append(edge)
            except Exception as e:
                print(f"Error processing pipe {p1} -> {p2}: {e}")
                continue

        return edges
    except Exception as e:
        print(f"Error in build_graph_with_kdtree: {e}")
        return []
