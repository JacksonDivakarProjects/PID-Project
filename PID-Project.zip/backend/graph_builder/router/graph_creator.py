from fastapi import APIRouter, UploadFile, File
import tempfile
from fastapi.responses import JSONResponse
import json
import numpy as np

from graph_builder.services.graph_create_services import load_components_from_excel,detect_pipes,build_graph_with_kdtree

router = APIRouter(prefix="/grp_creation", tags=["GRP_CREATION"])

def clean_nan_values(obj):
    """Recursively clean NaN values from nested dictionaries and lists"""
    if isinstance(obj, dict):
        return {k: clean_nan_values(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [clean_nan_values(item) for item in obj]
    elif isinstance(obj, float):
        if np.isnan(obj) or np.isinf(obj):
            return 0.0  # or None, depending on your preference
        return obj
    else:
        return obj

@router.post("/generate-graph")
async def generate_graph(excel: UploadFile = File(...), image: UploadFile = File(...)):
    try:
        # Save uploaded files to temp
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp_excel:
            tmp_excel.write(await excel.read())
            excel_path = tmp_excel.name

        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as tmp_img:
            tmp_img.write(await image.read())
            image_path = tmp_img.name

        # Run pipeline
        nodes, comp_centers = load_components_from_excel(excel_path)
        pipes = detect_pipes(image_path)
        edges = build_graph_with_kdtree(pipes, comp_centers)

        graph = {"nodes": nodes, "edges": edges}
        
        # Clean any NaN values before returning JSON
        clean_graph = clean_nan_values(graph)
        
        return JSONResponse(content=clean_graph)
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": f"Error processing graph: {str(e)}"}
        )
