import base64
import torch
import io
import cv2
import numpy as np
import pandas as pd
from PIL import Image
from sahi.slicing import slice_image
from torchvision.ops import nms
from ultralytics import YOLO

# --- CONFIGURATION ---
DEVICE = 'cpu'
MODEL_PATH = "obj_pred/services/best.pt"  # <--- CHANGE THIS TO YOUR MODEL PATH

# Load your local YOLO model
model = YOLO(MODEL_PATH)

# Create a mapping dictionary from the class numbers to component names
CLASS_MAPPING = {
    '1': 'Gate Valve', '2': 'Globe Valve', '3': 'Ball Valve', '4': 'Check Valve', '5': 'Pressure Instrument',
    '6': 'Control Valve', '7': 'Tagged Gate Valve', '8': 'Local Control Station', '9': 'Butterfly Valve',
    '10': 'Equipment Tag', '11': 'Diaphragm Valve', '12': 'Plug Valve', '13': 'Needle Valve',
    '14': 'Solenoid Valve', '15': 'Actuated Gate Valve', '16': 'Manual Butterfly Valve',
    '17': 'Safety Relief Valve', '18': 'Process Line Valve', '19': 'Level Instrument',
    '20': 'Flow Instrument', '21': 'Inline Strainer', '22': 'Speciality Valve',
    '23': 'Junction Box ID', '24': 'System Interface', '25': 'Tagged Control Valve',
    '26': 'Temperature Instrument', '27': 'High-Pressure Valve',
    '28': 'Utility Line Valve', '29': 'Drain Valve', '30': 'Operator Station',
    '31': 'Tagged Ball Valve', '32': 'Analysis Instrument'
}

async def perform_inference_and_nms(image_np: np.ndarray):
    """Performs SAHI slicing, YOLO inference, and NMS on a given image."""
    
    # Use SAHI to slice the image with 1024x1024 dimensions
    sliced_image_list = slice_image(
        image=image_np,
        slice_height=1024,
        slice_width=1024,
        overlap_height_ratio=0.2,
        overlap_width_ratio=0.2,
    )
    
    # A list to store all the predictions from all slices
    all_predictions = []
    
    # Loop through each slice and perform local inference
    for sliced_image in sliced_image_list:
        slice_data = sliced_image['image']
        
        # Get the starting coordinates from the 'starting_pixel' key
        y_start, x_start = sliced_image['starting_pixel']
        
        # Perform inference on the slice using your local model
        # The model expects a NumPy array (OpenCV format), so we convert it
        results = model.predict(cv2.cvtColor(slice_data, cv2.COLOR_RGB2BGR), conf=0.25, verbose=False, device=DEVICE)
        
        # Process the results from your local model
        for r in results:
            for box in r.boxes:
                # Extract box info
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                conf = float(box.conf[0].item())
                cls = int(box.cls[0].item())
                
                # Create a prediction dictionary in the same format as your original code
                prediction = {
                    "x": (x1 + x2) / 2,  # Center x in the slice
                    "y": (y1 + y2) / 2,  # Center y in the slice
                    "width": x2 - x1,
                    "height": y2 - y1,
                    "confidence": conf,
                    "class": str(cls)  # The class ID as a string, just like the API
                }
                
                # Adjust coordinates to the full image and store the prediction
                prediction['x'] += y_start  # Note: corrected order (was y_start, x_start)
                prediction['y'] += x_start
                all_predictions.append(prediction)
    
    # --- APPLY NON-MAXIMUM SUPPRESSION (NMS) ---
    # Convert predictions to a format suitable for NMS
    boxes = []
    scores = []
    original_indices = []
    
    for i, p in enumerate(all_predictions):
        x_center, y_center, width, height, confidence = p['x'], p['y'], p['width'], p['height'], p['confidence']
        x1 = x_center - width / 2
        y1 = y_center - height / 2
        x2 = x_center + width / 2
        y2 = y_center + height / 2
        boxes.append([x1, y1, x2, y2])
        scores.append(confidence)
        original_indices.append(i)
    
    if boxes:
        boxes_tensor = torch.tensor(boxes, dtype=torch.float32)
        scores_tensor = torch.tensor(scores, dtype=torch.float32)
        
        # Apply NMS
        keep_indices_tensor = nms(boxes_tensor, scores_tensor, iou_threshold=0.45)
        
        # Filter the original predictions based on NMS output
        final_predictions = [all_predictions[original_indices[i]] for i in keep_indices_tensor]
        return final_predictions
    
    return []
