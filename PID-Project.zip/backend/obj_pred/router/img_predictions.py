import base64
import io
import cv2
import numpy as np
import pandas as pd
import binascii
from fastapi import FastAPI, File, UploadFile, HTTPException, APIRouter
from fastapi.responses import StreamingResponse, JSONResponse
import os
from models.base_models import Base64Request, Base64Response
from obj_pred.services.perform_obj_pred import perform_inference_and_nms, CLASS_MAPPING

router = APIRouter(prefix="/img_pred", tags=["YOLO P&ID Inference API"])

@router.post("/predict-upload-json/", response_model=Base64Response)
async def predict_upload_and_get_json(file: UploadFile = File(...)):
    """
    Accepts an image file upload and returns a JSON object containing
    Base64 encoded strings for both the annotated image and the Excel data.
    """
    contents = await file.read()
    nparr = np.frombuffer(contents, np.uint8)
    image_np = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if image_np is None:
        raise HTTPException(status_code=400, detail="Invalid image file provided.")

    try:
        final_predictions = await perform_inference_and_nms(image_np)

        # --- Generate Excel data and encode it to Base64 ---
        if not final_predictions:
            df = pd.DataFrame(columns=['x', 'y', 'width', 'height', 'confidence', 'class', 'Component Name'])
        else:
            df = pd.DataFrame(final_predictions)
            df['Component Name'] = df['class'].map(CLASS_MAPPING)
        
        excel_buffer = io.BytesIO()
        df.to_excel(excel_buffer, index=False, engine='openpyxl')
        excel_buffer.seek(0)
        excel_base64 = base64.b64encode(excel_buffer.read()).decode('utf-8')

        # --- Generate annotated image with new code styling ---
        for p in final_predictions:
            # Get coordinates from the prediction
            x_center, y_center = p['x'], p['y']
            width, height = p['width'], p['height']
            class_id = p['class']  # Use 'class' which is string
            
            # Convert center coordinates to top-left corner coordinates
            x1 = int(x_center - width / 2)
            y1 = int(y_center - height / 2)
            x2 = int(x_center + width / 2)
            y2 = int(y_center + height / 2)
            
            # Draw the bounding box (rectangle) on the image
            color = (0, 255, 0)  # Green color in BGR format
            thickness = 2
            cv2.rectangle(image_np, (x1, y1), (x2, y2), color, thickness)
            
            # Get the component name from the mapping dictionary
            component_name = CLASS_MAPPING.get(class_id, "Unknown")
            label = f"{class_id}: {component_name}"
            
            # Put the class number and component name text on the image
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 0.5
            font_thickness = 1
            text_color = (0, 0, 255)  # Red color for text
            cv2.putText(image_np, label, (x1, y1 - 10), font, font_scale, text_color, font_thickness)
        
        is_success, image_buffer_encoded = cv2.imencode(".png", image_np)
        if not is_success:
            raise HTTPException(status_code=500, detail="Could not encode image to PNG.")
        image_base64 = base64.b64encode(image_buffer_encoded.tobytes()).decode('utf-8')
        # Save the annotated image locally
        os.makedirs("/tmp", exist_ok=True)

        output_image_path = f"/tmp/annotated_{file.filename}"
        with open(output_image_path, "wb") as f:
            f.write(image_buffer_encoded.tobytes())
        # Return the Pydantic response model
        return Base64Response(
            filename=file.filename,
            annotated_image_base64=image_base64,
            excel_data_base64=excel_base64
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error during prediction: {e}")

@router.post("/predict-json/", response_model=Base64Response)
async def predict_base64_and_get_json(request: Base64Request):
    """
    Accepts a Base64 encoded image and returns a JSON object containing
    Base64 encoded strings for both the annotated image and the Excel data.
    """
    try:
        image_bytes = base64.b64decode(request.image_base64)
    except (binascii.Error, TypeError):
        raise HTTPException(status_code=400, detail="Invalid Base64 string provided.")
    
    nparr = np.frombuffer(image_bytes, np.uint8)
    image_np = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    if image_np is None:
        raise HTTPException(status_code=400, detail="Base64 string does not represent a valid image.")
    
    try:
        final_predictions = await perform_inference_and_nms(image_np)
        
        if not final_predictions:
            df = pd.DataFrame(columns=['x', 'y', 'width', 'height', 'confidence', 'class', 'Component Name'])
        else:
            df = pd.DataFrame(final_predictions)
            df['Component Name'] = df['class'].map(CLASS_MAPPING)
        
        excel_buffer = io.BytesIO()
        df.to_excel(excel_buffer, index=False, engine='openpyxl')
        excel_buffer.seek(0)
        excel_base64 = base64.b64encode(excel_buffer.read()).decode('utf-8')
        
        # --- Generate annotated image with new code styling ---
        for p in final_predictions:
            # Get coordinates from the prediction
            x_center, y_center = p['x'], p['y']
            width, height = p['width'], p['height']
            class_id = p['class']  # Use 'class' which is string
            
            # Convert center coordinates to top-left corner coordinates
            x1 = int(x_center - width / 2)
            y1 = int(y_center - height / 2)
            x2 = int(x_center + width / 2)
            y2 = int(y_center + height / 2)
            
            # Draw the bounding box (rectangle) on the image
            color = (0, 255, 0)  # Green color in BGR format
            thickness = 2
            cv2.rectangle(image_np, (x1, y1), (x2, y2), color, thickness)
            
            # Get the component name from the mapping dictionary
            component_name = CLASS_MAPPING.get(class_id, "Unknown")
            label = f"{class_id}: {component_name}"
            
            # Put the class number and component name text on the image
            font = cv2.FONT_HERSHEY_SIMPLEX
            font_scale = 0.5
            font_thickness = 1
            text_color = (0, 0, 255)  # Red color for text
            cv2.putText(image_np, label, (x1, y1 - 10), font, font_scale, text_color, font_thickness)
        
        is_success, image_buffer_encoded = cv2.imencode(".png", image_np)
        if not is_success:
            raise HTTPException(status_code=500, detail="Could not encode image to PNG.")
        image_base64 = base64.b64encode(image_buffer_encoded.tobytes()).decode('utf-8')
        
        return Base64Response(
            filename=request.filename,
            annotated_image_base64=image_base64,
            excel_data_base64=excel_base64
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error during prediction: {e}")

@router.get("/")
def read_root():
    return {
        "message": "Welcome to YOLO P&ID Inference API!",
        "endpoints": {
            "/predict-upload-json/": "Upload an image file to get a JSON response.",
            "/predict-json/": "Send a JSON payload with a Base64 image to get a JSON response."
        }
    }
