from fastapi import FastAPI, Request, APIRouter, File, UploadFile, Form
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel
from typing import List, Optional
import base64
import io
from PIL import Image

from models.base_models import ChatMessage, ChatRequest
from flow_agent.services.agent import (
    stream_chat_completion, 
    stream_plain_text,
    stream_chat_completion_with_image,
    stream_plain_text_with_image,
    chat_completion_with_image  # Import the new function
)

router = APIRouter(prefix="/agent", tags=["agent"])

# Extended models for image support
class ImageChatMessage(BaseModel):
    role: str
    content: str

class ImageChatRequest(BaseModel):
    messages: List[ImageChatMessage]
    image_base64: Optional[str] = None



# 🆕 NEW FILE UPLOAD NON-STREAMING ENDPOINT
@router.post("/chat/line-detection")
async def upload_image_complete_endpoint(
    file: UploadFile = File(...),
    message: str = Form(...)
):
    """
    Upload image file and get complete (non-streaming) response as JSON
    """
    try:
        # Read and process the uploaded image
        image_data = await file.read()
        
        # Convert to base64
        image_base64 = base64.b64encode(image_data).decode('utf-8')
        
        # Prepare message
        messages = [{"role": "user", "content": message}]
        
        # Get complete response
        response = await chat_completion_with_image(
            messages=messages,
            image_data=image_base64
           
        )
        
        return {
            "response": response,
            "filename": file.filename,
            "status": "success"
        }
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={
                "error": str(e),
                "status": "error"
            }
        )

# Image + Text streaming endpoints (existing)
@router.post("/stream/query_agent")
async def stream_image_chat_endpoint(chat_request: ImageChatRequest):
    """
    FastAPI endpoint for streaming chat responses with image support
    """
    messages = [msg.dict() for msg in chat_request.messages]
    
    return StreamingResponse(
        stream_chat_completion_with_image(
            messages=messages,
            image_data=chat_request.image_base64,
            
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )



@router.post("/stream/plain")
async def plain_stream_endpoint(chat_request: ChatRequest):
    """
    Plain text streaming endpoint (text only)
    """
    messages = [msg.dict() for msg in chat_request.messages]
    
    return StreamingResponse(
        stream_plain_text(
            messages=messages
        ),
        media_type="text/plain"
    )

@router.get("/stream/simple")
async def simple_stream_endpoint(user_message: str = "Hello"):
    """
    Simple GET endpoint for quick testing
    """
    messages = [{"role": "user", "content": user_message}]
    
    return StreamingResponse(
        stream_chat_completion(messages=messages),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )