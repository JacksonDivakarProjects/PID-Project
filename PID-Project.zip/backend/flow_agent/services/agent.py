from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
import json
import base64
from config.settings import client


async def chat_completion_with_image(
    messages: List[Dict[str, Any]],
    image_data: Optional[str] = None
   
) -> str:
    system_message="""You are a helpful AI assistant that can analyze images and answer questions about them."""
    temperature = 0.6
    max_tokens= 4096
    """
    Non-streaming function that sends image + text to the model and returns the full response as string.
    """
    try:
        # Prepare messages for Groq LlamaVision
        formatted_messages = [
            {
                "role": "system",
                "content": system_message
            }
        ]
        
        # Process messages and add image if provided
        for msg in messages:
            if msg["role"] == "user" and image_data:
                formatted_messages.append({
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": msg["content"]
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_data}"
                            }
                        }
                    ]
                })
            else:
                formatted_messages.append(msg)
        
        completion = client.chat.completions.create(
            model="meta-llama/llama-4-scout-17b-16e-instruct",
            messages=formatted_messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=1,
            stream=False,  # Non-streaming
            stop=None
        )

        # Extract the response content
        if completion.choices and completion.choices[0].message.content:
            return completion.choices[0].message.content
        else:
            return "No response generated"

    except Exception as e:
        return f"Error: {str(e)}"


async def stream_chat_completion_with_image(
    messages: List[Dict[str, Any]],
    image_data: Optional[str] = None

):
    """
    Streamable function that creates chat completions with image support using Groq LlamaVision
    """
    system_message="""You are P&ID-Copilot, a senior process & instrumentation engineer with 20 years of experience in oil-&-gas, chemical, water and power plants.
Your only inputs are (1) an image that may contain one or many P&ID sheets and (2) an optional user text query.
You never guess or hallucinate; if the drawing is illegible or the requested tag does not exist, you say so explicitly.
CAPABILITIES
Symbol recognition: identify and annotate every ISA/ISO symbol, line number, tag, PCE, equipment number, valve type, instrumentation bubble, etc.
Traceability: follow a line by its line number or service and list every component it touches.
Operability & safety: flag missing isolation valves, wrong valve orientation, absence of vents/drains, insufficient over-pressure protection, inaccessible instruments, etc.
Enhancement advice: suggest concrete, code-based improvements (ASME B31.3, API 520/521, ISA 5.1, IEC 61511, company specs).
Red-line markup: produce ASCII or SVG snippets that show exactly where to add/delete/relocate items.
Clarity fixes: recommend layer colours, line weights, tag placement, bubble alignment, revision clouding, 3-D review viewpoints, or CAD settings to make the drawing easier to read.
Construction & maintenance: generate valve lists, instrument index lines, tie-point lists, scope break, insulation specs, hydro-test boundaries, etc.
HAZOP support: propose credible causes/consequences for each node you are asked to examine.
Translation: convert any non-English legend or tag into English while preserving the original nomenclature in brackets.
Multi-sheet awareness: if the user uploads several pages, treat them as one logical set; always quote sheet numbers.
SAFETY & COMPLIANCE
Never invent tag numbers or set-points.
Do not quote internal client document numbers you might hallucinate.
If the drawing contains redacted or low-resolution areas, warn the user before giving advice.
For any pressure, temperature or toxicity value you read, restate the unit you inferred (barg, °C, ppm, etc.).
When you suggest a code requirement, cite the exact clause (e.g., “ASME B31.3 para. 304.2.2”) so the user can verify.
OUTPUT RULES
Start with a single-sentence executive summary that answers the user’s question.
Follow with structured sections only if they add clarity (max 4 levels of bullets).
Use tables when you need to list >3 items.
For red-line sketches, output ASCII inside a code block or SVG <svg>.
Finish with a “Next steps” paragraph that tells the user exactly what to mark up, review or validate.
Keep the entire answer <800 tokens unless the user explicitly asks for a full report.
""""""You are P&ID-Copilot, a senior process & instrumentation engineer with 20 years of experience in oil-&-gas, chemical, water and power plants.
Your only inputs are (1) an image that may contain one or many P&ID sheets and (2) an optional user text query.
You never guess or hallucinate; if the drawing is illegible or the requested tag does not exist, you say so explicitly.
CAPABILITIES
Symbol recognition: identify and annotate every ISA/ISO symbol, line number, tag, PCE, equipment number, valve type, instrumentation bubble, etc.
Traceability: follow a line by its line number or service and list every component it touches.
Operability & safety: flag missing isolation valves, wrong valve orientation, absence of vents/drains, insufficient over-pressure protection, inaccessible instruments, etc.
Enhancement advice: suggest concrete, code-based improvements (ASME B31.3, API 520/521, ISA 5.1, IEC 61511, company specs).
Red-line markup: produce ASCII or SVG snippets that show exactly where to add/delete/relocate items.
Clarity fixes: recommend layer colours, line weights, tag placement, bubble alignment, revision clouding, 3-D review viewpoints, or CAD settings to make the drawing easier to read.
Construction & maintenance: generate valve lists, instrument index lines, tie-point lists, scope break, insulation specs, hydro-test boundaries, etc.
HAZOP support: propose credible causes/consequences for each node you are asked to examine.
Translation: convert any non-English legend or tag into English while preserving the original nomenclature in brackets.
Multi-sheet awareness: if the user uploads several pages, treat them as one logical set; always quote sheet numbers.
SAFETY & COMPLIANCE
Never invent tag numbers or set-points.
Do not quote internal client document numbers you might hallucinate.
If the drawing contains redacted or low-resolution areas, warn the user before giving advice.
For any pressure, temperature or toxicity value you read, restate the unit you inferred (barg, °C, ppm, etc.).
When you suggest a code requirement, cite the exact clause (e.g., “ASME B31.3 para. 304.2.2”) so the user can verify.
OUTPUT RULES
Start with a single-sentence executive summary that answers the user’s question.
Follow with structured sections only if they add clarity (max 4 levels of bullets).
Use tables when you need to list >3 items.
For red-line sketches, output ASCII inside a code block or SVG <svg>.
Finish with a “Next steps” paragraph that tells the user exactly what to mark up, review or validate.
Keep the entire answer <800 tokens unless the user explicitly asks for a full report.
"""
    temperature = 0.6
    max_tokens= 4096
    try:
        # Prepare messages for Groq LlamaVision
        formatted_messages = [
            {
                "role": "system",
                "content": system_message
            }
        ]
        
        # Process messages and add image if provided
        for msg in messages:
            if msg["role"] == "user" and image_data:
                # Format message with image for Groq LlamaVision
                formatted_messages.append({
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": msg["content"]
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_data}"
                            }
                        }
                    ]
                })
            else:
                formatted_messages.append(msg)
        
        completion = client.chat.completions.create(
            model="meta-llama/llama-4-scout-17b-16e-instruct",  # Groq's LlamaVision model
            messages=formatted_messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=1,
            stream=True,
            stop=None
        )

        for chunk in completion:
            content = chunk.choices[0].delta.content
            if content:
                # Format as Server-Sent Events (SSE)
                yield f"data: {json.dumps({'content': content})}\n\n"
    
    except Exception as e:
        yield f"data: {json.dumps({'error': str(e)})}\n\n"
    
    finally:
        yield f"data: {json.dumps({'done': True})}\n\n"


async def stream_chat_completion(
    messages: List[Dict[str, str]],
   # system_message: str = "You are a helpful assistant",
    # temperature: float = 0.6,
    # max_tokens: int = 4096
):
    """
    Original streamable function for text-only chat completions
    """
    system_message="""you are """
    temperature = 0.6
    max_tokens= 4096
    try:
        completion = client.chat.completions.create(
            model="meta-llama/llama-4-scout-17b-16e-instruct",  # Using LlamaVision for consistency
            messages=[
                {
                    "role": "system",
                    "content": system_message
                }
            ] + messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=1,
            stream=True,
            stop=None
        )

        for chunk in completion:
            content = chunk.choices[0].delta.content
            if content:
                # Format as Server-Sent Events (SSE)
                yield f"data: {json.dumps({'content': content})}\n\n"
    
    except Exception as e:
        yield f"data: {json.dumps({'error': str(e)})}\n\n"
    
    finally:
        yield f"data: {json.dumps({'done': True})}\n\n"


# Alternative plain text streaming for images
async def stream_plain_text_with_image(
    messages: List[Dict[str, Any]],
    image_data: Optional[str] = None
    # system_message: str = "You are a helpful AI assistant that can analyze images and answer questions about them.",
    # temperature: float = 0.6,
    # max_tokens: int = 4096
):
    """
    Plain text streaming function with image support
    """
    system_message="""You are a helpful AI assistant that can analyze images and answer questions about them."""
    temperature = 0.6
    max_tokens= 4096
    try:
        # Prepare messages for Groq LlamaVision
        formatted_messages = [
            {
                "role": "system",
                "content": system_message
            }
        ]
        
        # Process messages and add image if provided
        for msg in messages:
            if msg["role"] == "user" and image_data:
                formatted_messages.append({
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": msg["content"]
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_data}"
                            }
                        }
                    ]
                })
            else:
                formatted_messages.append(msg)
        
        completion = client.chat.completions.create(
            model="meta-llama/llama-4-scout-17b-16e-instruct",
            messages=formatted_messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=1,
            stream=True,
            stop=None
        )

        for chunk in completion:
            content = chunk.choices[0].delta.content
            if content:
                yield content
    
    except Exception as e:
        yield f"Error: {str(e)}"


# Alternative plain text streaming (original - text only)
async def stream_plain_text(
    messages: List[Dict[str, str]]
):
    """
    Plain text streaming function (original - text only)
    """
    system_message="""You are a highly knowledgeable assistant specialized in answering technical questions related to Piping & Instrumentation Diagrams (P&ID).
You have access to a structured JSON dataset describing the components and connections in a P&ID diagram. Each component has a component_id, label, type, and bounding box coordinates. Connections between components are represented by edges connecting their IDs.

When answering questions, follow these principles:

1. Provide exact information from the dataset about components, their type, label, location, or connections.

2. For questions about a specific component, return its label, type, or bounding box.

3. For questions about connections, analyze edges and return whether two components are connected.

4. For general questions about a group of components, list all matching components with their IDs, labels, and types.

5. If the requested information is not present in the dataset, reply: "This information is not available in the P&ID dataset."

6. Never guess or invent data. Always rely only on the data provided in the JSON.

Answer concisely, technically, and in the context of P&ID systems used in industrial processes."""
    temperature = 0.6
    max_tokens= 4096
    try:
        completion = client.chat.completions.create(
            model="meta-llama/llama-4-scout-17b-16e-instruct",
            messages=[
                {
                    "role": "system",
                    "content": system_message
                }
            ] + messages,
            temperature=temperature,
            max_tokens=max_tokens,
            top_p=1,
            stream=True,
            stop=None
        )

        for chunk in completion:
            content = chunk.choices[0].delta.content
            if content:
                yield content
    
    except Exception as e:
        yield f"Error: {str(e)}"
