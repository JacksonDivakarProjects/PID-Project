from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import FileResponse
import uvicorn
import json
import pandas as pd
import numpy as np
import tempfile
import os
from datetime import datetime
from typing import List, Dict, Any

app = FastAPI(title="P&ID Connection Analyzer", version="1.0.0")

class PIDConnectionAnalyzer:
    def __init__(self):
        self.mapped_components = {}
        self.connection_flags = []
        self.valid_connections = []
        
    def analyze_connections(self, image_data: bytes, json_data: dict) -> Dict[str, Any]:
        """Main analysis function"""
        # Load and validate components
        nodes = json_data.get('nodes', [])
        edges = json_data.get('edges', [])
        
        # Create mapped components dictionary
        self.mapped_components = {node['id']: node for node in nodes}
        
        # Process existing connections from JSON
        valid_connections = self.process_existing_connections(edges)
        
        # Detect missing/broken connections
        connection_flags = self.detect_connection_issues(nodes, edges)
        
        # Generate comprehensive report
        report = self.generate_connection_report(valid_connections, connection_flags)
        
        return report
    
    def process_existing_connections(self, edges: List[Dict]) -> List[Dict]:
        """Process connections from JSON edges"""
        valid_connections = []
        
        for edge in edges:
            from_id = edge.get('from')
            to_id = edge.get('to')
            
            # Validate both components exist and are properly mapped
            if (from_id in self.mapped_components and 
                to_id in self.mapped_components):
                
                from_comp = self.mapped_components[from_id]
                to_comp = self.mapped_components[to_id]
                
                connection = {
                    'connection_id': f"{from_id}_to_{to_id}",
                    'from_component_id': from_comp.get('component_id', from_id),
                    'from_component_type': from_comp.get('label', 'Unknown'),
                    'to_component_id': to_comp.get('component_id', to_id), 
                    'to_component_type': to_comp.get('label', 'Unknown'),
                    'connection_length': edge.get('length', 0),
                    'status': 'CONNECTED',
                    'confidence': 'HIGH',
                    'validation_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                valid_connections.append(connection)
            else:
                # Flag invalid connection
                self.connection_flags.append({
                    'flag_type': 'INVALID_CONNECTION',
                    'from_component': str(from_id),
                    'to_component': str(to_id),
                    'issue': 'One or both components not properly mapped',
                    'severity': 'HIGH',
                    'action_required': 'Verify component detection'
                })
        
        return valid_connections
    
    def detect_connection_issues(self, nodes: List[Dict], edges: List[Dict]) -> List[Dict]:
        """Detect various connection issues and flag them"""
        flags = []
        
        # Get all connected component IDs
        connected_components = set()
        for edge in edges:
            connected_components.add(edge.get('from'))
            connected_components.add(edge.get('to'))
        
        # Check for isolated components
        for node in nodes:
            node_id = node['id']
            
            if node_id not in connected_components:
                # FIX: Convert bbox list to string format
                bbox_str = str(node.get('bbox', [])) if node.get('bbox') else "[]"
                
                flags.append({
                    'flag_type': 'ISOLATED_COMPONENT',
                    'component_id': str(node.get('component_id', node_id)),
                    'component_type': str(node.get('label', 'Unknown')),
                    'bbox_coordinates': bbox_str,  # Changed from 'bbox' to 'bbox_coordinates'
                    'issue': 'Component has no connections',
                    'severity': 'HIGH',
                    'action_required': 'Verify if component should have piping connections',
                    'detection_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
        
        # Check for components with only one connection
        component_connection_count = {}
        for edge in edges:
            from_id = edge.get('from')
            to_id = edge.get('to')
            
            component_connection_count[from_id] = component_connection_count.get(from_id, 0) + 1
            component_connection_count[to_id] = component_connection_count.get(to_id, 0) + 1
        
        for comp_id, count in component_connection_count.items():
            if count == 1 and comp_id in self.mapped_components:
                component = self.mapped_components[comp_id]
                flags.append({
                    'flag_type': 'SINGLE_CONNECTION',
                    'component_id': str(component.get('component_id', comp_id)),
                    'component_type': str(component.get('label', 'Unknown')),
                    'bbox_coordinates': str(component.get('bbox', [])),
                    'issue': 'Component has only one connection - potential dead end',
                    'severity': 'MEDIUM',
                    'action_required': 'Verify if additional connections are missing',
                    'detection_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
        
        # Check for suspicious long connections
        for edge in edges:
            length = edge.get('length', 0)
            if length > 1000:  # Threshold for suspicious connections
                flags.append({
                    'flag_type': 'SUSPICIOUS_LONG_CONNECTION',
                    'from_component': str(edge.get('from')),
                    'to_component': str(edge.get('to')),
                    'connection_length': float(length),  # Ensure numeric
                    'bbox_coordinates': '',  # Empty for connection flags
                    'issue': f'Unusually long connection ({length} pixels)',
                    'severity': 'MEDIUM',
                    'action_required': 'Verify connection path accuracy',
                    'detection_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
        
        return flags
    
    def generate_connection_report(self, connections: List[Dict], flags: List[Dict]) -> Dict[str, Any]:
        """Generate comprehensive connection report"""
        
        # Statistics
        total_components = len(self.mapped_components)
        total_connections = len(connections)
        total_flags = len(flags)
        
        # Component type distribution
        component_types = {}
        for comp in self.mapped_components.values():
            comp_type = comp.get('label', 'Unknown')
            component_types[comp_type] = component_types.get(comp_type, 0) + 1
        
        # Flag severity distribution
        flag_severity = {'HIGH': 0, 'MEDIUM': 0, 'LOW': 0}
        for flag in flags:
            severity = flag.get('severity', 'LOW')
            flag_severity[severity] += 1
        
        return {
            'summary': {
                'total_components': total_components,
                'total_connections': total_connections,
                'total_flags': total_flags,
                'connection_rate': f"{(total_connections/(total_components*2))*100:.1f}%" if total_components > 0 else "0%",
                'analysis_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            },
            'connections': connections,
            'flags': flags,
            'statistics': {
                'component_types': component_types,
                'flag_severity': flag_severity
            }
        }

@app.post("/analyze_pid_connections")
async def analyze_pid_connections(
    image: UploadFile = File(..., description="P&ID diagram image file"),
    json_file: UploadFile = File(..., description="Component detection JSON file")
):
    """
    Analyze P&ID connections and return Excel report
    """
    
    try:
        # Read uploaded files
        image_data = await image.read()
        json_data_raw = await json_file.read()
        
        # Parse JSON data
        try:
            json_data = json.loads(json_data_raw.decode('utf-8'))
        except json.JSONDecodeError as e:
            raise HTTPException(status_code=400, detail=f"Invalid JSON format: {str(e)}")
        
        # Validate JSON structure
        if 'nodes' not in json_data:
            raise HTTPException(status_code=400, detail="JSON must contain 'nodes' array")
        
        # Initialize analyzer and process
        analyzer = PIDConnectionAnalyzer()
        report = analyzer.analyze_connections(image_data, json_data)
        
        # Create Excel file
        excel_file = create_excel_report(report)
        
        return FileResponse(
            excel_file,
            media_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            filename=f'pid_connection_report_{datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {str(e)}")

def create_excel_report(report: Dict[str, Any]) -> str:
    """Create Excel file with multiple sheets - FIXED VERSION"""
    
    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx')
    temp_filepath = temp_file.name
    temp_file.close()
    
    try:
        # Use openpyxl engine (more reliable than xlsxwriter)
        with pd.ExcelWriter(temp_filepath, engine='openpyxl') as writer:
            
            # 1. Connections Sheet
            if report['connections']:
                # Ensure all values are Excel-compatible
                connections_clean = []
                for conn in report['connections']:
                    clean_conn = {}
                    for key, value in conn.items():
                        # Convert any complex types to strings
                        if isinstance(value, (list, dict)):
                            clean_conn[key] = str(value)
                        else:
                            clean_conn[key] = value
                    connections_clean.append(clean_conn)
                
                df_connections = pd.DataFrame(connections_clean)
                df_connections.to_excel(writer, sheet_name='Valid_Connections', index=False)
            
            # 2. Flags Sheet  
            if report['flags']:
                # Ensure all values are Excel-compatible
                flags_clean = []
                for flag in report['flags']:
                    clean_flag = {}
                    for key, value in flag.items():
                        # Convert any complex types to strings
                        if isinstance(value, (list, dict)):
                            clean_flag[key] = str(value)
                        else:
                            clean_flag[key] = value
                    flags_clean.append(clean_flag)
                
                df_flags = pd.DataFrame(flags_clean)
                df_flags.to_excel(writer, sheet_name='Connection_Flags', index=False)
            
            # 3. Summary Sheet
            summary_data = []
            for key, value in report['summary'].items():
                summary_data.append({
                    'Metric': key.replace('_', ' ').title(), 
                    'Value': str(value)
                })
            
            # Add component type statistics
            for comp_type, count in report['statistics']['component_types'].items():
                summary_data.append({
                    'Metric': f'Components - {comp_type}', 
                    'Value': str(count)
                })
            
            # Add flag severity statistics  
            for severity, count in report['statistics']['flag_severity'].items():
                summary_data.append({
                    'Metric': f'Flags - {severity} Severity', 
                    'Value': str(count)
                })
            
            df_summary = pd.DataFrame(summary_data)
            df_summary.to_excel(writer, sheet_name='Analysis_Summary', index=False)
    
    except Exception as e:
        # Clean up temp file on error
        if os.path.exists(temp_filepath):
            os.unlink(temp_filepath)
        raise Exception(f"Excel creation failed: {str(e)}")
    
    return temp_filepath

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "P&ID Connection Analyzer"}

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "service": "P&ID Connection Analyzer API",
        "version": "1.0.0",
        "endpoints": {
            "analyze": "/analyze_pid_connections",
            "health": "/health"
        },
        "description": "Upload P&ID image and JSON to get connection analysis report"
    }

if __name__ == "__main__":
    print("Starting P&ID Connection Analyzer API...")
    print("\nRequired packages:")
    print("pip install fastapi uvicorn pandas openpyxl pillow python-multipart")
    print("\nStarting server on http://localhost:8000")
    uvicorn.run("mn:app", host="0.0.0.0", port=8000, reload=True)
