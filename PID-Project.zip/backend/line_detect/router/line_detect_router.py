from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import JSONResponse
from typing import Dict, Any
from line_detect.services.line_detect_ser import PIDAnalysisService

router = APIRouter(prefix="/pid-analysis", tags=["P&ID Analysis"])

# Initialize service
pid_service = PIDAnalysisService()

@router.post("/analyze", response_model=Dict[str, Any])
async def analyze_pid_diagram(
    excel_file: UploadFile = File(..., description="Excel file containing component data"),
    image_file: UploadFile = File(..., description="Image file of P&ID diagram")
):
    """
    Analyze P&ID diagram for component connections and convert to industrial formats.
    
    - **excel_file**: Excel file with component data (columns: x, y, width, height, Component Name, class, extracted_text)
    - **image_file**: Image file of the P&ID diagram (JPG, PNG, etc.)
    
    Returns:
    - **raw_graph_json_base64**: Base64 encoded raw JSON graph data
    - **industrial_json_base64**: Base64 encoded industrial-ready JSON format
    - **dexpi_xml_base64**: Base64 encoded DEXPI XML format
    - **statistics_excel_base64**: Base64 encoded Excel file with pipe statistics
    - **summary**: Human-readable summary of connections
    - **low_confidence_stats**: List of low confidence connections
    - **total_connections**: Number of connections found
    - **total_components**: Number of components loaded
    - **pipes_detected**: Number of pipes detected
    """
    
    # Validate file types
    if not excel_file.filename.lower().endswith(('.xlsx', '.xls')):
        raise HTTPException(status_code=400, detail="Excel file must be .xlsx or .xls format")
    
    allowed_image_types = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']
    if not any(image_file.filename.lower().endswith(ext) for ext in allowed_image_types):
        raise HTTPException(status_code=400, detail="Image file must be in JPG, PNG, BMP, or TIFF format")
    
    try:
        # Process the P&ID analysis
        result = pid_service.process_pid_analysis(excel_file, image_file)
        
        if not result["success"]:
            raise HTTPException(status_code=400, detail=result["error"])
        
        return JSONResponse(content=result)
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@router.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "P&ID Analysis API"}

@router.get("/formats")
async def get_supported_formats():
    """Get information about supported output formats."""
    return {
        "supported_formats": {
            "raw_graph_json": {
                "description": "Raw graph data with nodes and edges",
                "format": "JSON",
                "encoding": "base64"
            },
            "industrial_json": {
                "description": "Industrial-ready JSON format with Equipment and Pipelines",
                "format": "JSON",
                "encoding": "base64"
            },
            "dexpi_xml": {
                "description": "DEXPI XML format for industrial plant modeling",
                "format": "XML",
                "encoding": "base64"
            },
            "statistics_excel": {
                "description": "Excel file with detailed pipe connection statistics",
                "format": "Excel",
                "encoding": "base64"
            }
        }
    }
