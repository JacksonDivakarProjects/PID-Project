import cv2
import pandas as pd
import numpy as np
import uuid
import json
import base64
import io
import xml.etree.ElementTree as ET
from xml.dom import minidom
from scipy.spatial import KDTree
from typing import List, Dict, Tuple, Optional
from fastapi import UploadFile
import tempfile
import os

class PIDAnalysisService:
    
    @staticmethod
    def clean_nan_values(obj):
        """Recursively clean NaN values from nested dictionaries and lists."""
        if isinstance(obj, dict):
            return {k: PIDAnalysisService.clean_nan_values(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [PIDAnalysisService.clean_nan_values(item) for item in obj]
        elif isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
            return None
        else:
            return obj
    
    @staticmethod
    def load_components_from_excel(excel_file: UploadFile) -> Tuple[Optional[List[Dict]], Optional[List[Tuple]]]:
        """Loads component data from an Excel file into a list of node objects."""
        try:
            content = excel_file.file.read()
            excel_file.file.seek(0)
            
            with tempfile.NamedTemporaryFile(delete=False, suffix='.xlsx') as tmp_file:
                tmp_file.write(content)
                tmp_file_path = tmp_file.name
            
            try:
                df = pd.read_excel(tmp_file_path)
                df = df.fillna({
                    'x': 0,
                    'y': 0,
                    'width': 0,
                    'height': 0,
                    'Component Name': 'Unknown',
                    'class': 'N/A',
                    'extracted_text': 'N/A'
                })
            finally:
                os.unlink(tmp_file_path)
                
        except Exception as e:
            print(f"🛑 Error: Could not read the Excel file: {e}")
            return None, None
            
        nodes = []
        comp_centers = []

        for _, row in df.iterrows():
            x = float(row["x"]) if pd.notna(row["x"]) else 0.0
            y = float(row["y"]) if pd.notna(row["y"]) else 0.0
            w = float(row["width"]) if pd.notna(row["width"]) else 0.0
            h = float(row["height"]) if pd.notna(row["height"]) else 0.0
            
            bbox = [x, y, x + w, y + h]
            node_id = str(uuid.uuid4())
            
            component_name = str(row["Component Name"]) if pd.notna(row["Component Name"]) else "Unknown"
            class_id_value = str(row.get("class", "N/A")) if pd.notna(row.get("class")) else "N/A"
            extracted_text = str(row["extracted_text"]) if pd.notna(row["extracted_text"]) else "N/A"

            node = {
                "id": node_id,
                "label": component_name,
                "type": class_id_value,
                "bbox": bbox,
                "component_id": extracted_text
            }
            nodes.append(node)

            center = ((x + x + w) / 2, (y + y + h) / 2)
            comp_centers.append((center, node_id))

        return nodes, comp_centers

    @staticmethod
    def detect_pipes(image_file: UploadFile) -> List[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """Detects straight lines in an image to represent pipes."""
        try:
            content = image_file.file.read()
            image_file.file.seek(0)
            
            nparr = np.frombuffer(content, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
            
            if img is None:
                print(f"🛑 Error: Could not decode the image file.")
                return []
                
        except Exception as e:
            print(f"🛑 Error loading image: {e}")
            return []
            
        edges = cv2.Canny(img, 50, 150, apertureSize=3)
        lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=80,
                                minLineLength=40, maxLineGap=15)

        pipes = []
        if lines is not None:
            for line in lines:
                x1, y1, x2, y2 = line[0]
                pipes.append(((int(x1), int(y1)), (int(x2), int(y2))))
        return pipes

    @staticmethod
    def build_graph_with_kdtree(pipes: List[Tuple], comp_centers: List[Tuple]) -> List[Dict]:
        """Connects pipes to the nearest components and calculates confidence."""
        if not comp_centers:
            return []
            
        centers = np.array([c[0] for c in comp_centers])
        ids = [c[1] for c in comp_centers]
        
        if len(centers) == 0:
            return []
            
        tree = KDTree(centers)
        edges = []
        
        MAX_SNAP_DISTANCE = 50.0

        for (p1, p2) in pipes:
            try:
                dist1, idx1 = tree.query(p1)
                dist2, idx2 = tree.query(p2)
                
                if np.isnan(dist1) or np.isnan(dist2) or np.isinf(dist1) or np.isinf(dist2):
                    continue
                    
                comp1_id = ids[idx1]
                comp2_id = ids[idx2]

                if comp1_id != comp2_id:
                    length = np.linalg.norm(np.array(p1) - np.array(p2))
                    
                    if np.isnan(length) or np.isinf(length):
                        continue
                        
                    flag = "OK"
                    if dist1 > MAX_SNAP_DISTANCE or dist2 > MAX_SNAP_DISTANCE:
                        flag = "LOW_CONFIDENCE_CONNECTION"
                    
                    avg_dist = (dist1 + dist2) / 2.0
                    confidence_score = max(0, 1.0 - (avg_dist / MAX_SNAP_DISTANCE))
                    
                    if np.isnan(confidence_score) or np.isinf(confidence_score):
                        confidence_score = 0.0
                    
                    edge = {
                        "from": comp1_id,
                        "to": comp2_id,
                        "length": float(length),
                        "confidence_score": round(float(confidence_score), 3),
                        "flag": flag
                    }
                    
                    if not any(((e["from"] == edge["from"] and e["to"] == edge["to"]) or
                                (e["from"] == edge["to"] and e["to"] == edge["from"]))
                               for e in edges):
                        edges.append(edge)
            except Exception as e:
                print(f"Error processing pipe connection: {e}")
                continue
                
        return edges

    @staticmethod
    def export_to_json_base64(nodes: List[Dict], edges: List[Dict]) -> str:
        """Creates JSON and returns it as base64 encoded string."""
        clean_nodes = PIDAnalysisService.clean_nan_values(nodes)
        clean_edges = PIDAnalysisService.clean_nan_values(edges)
        
        graph = {"nodes": clean_nodes, "edges": clean_edges}
        json_str = json.dumps(graph, indent=2)
        json_bytes = json_str.encode('utf-8')
        return base64.b64encode(json_bytes).decode('utf-8')

    @staticmethod
    def create_structured_json(data: Dict) -> Dict:
        """Converts the graph JSON to a structured 'Industrial JSON' format."""
        node_map = {node['id']: node for node in data['nodes']}
        
        industrial_data = {
            "Equipment": [],
            "Pipelines": []
        }
        
        # Process nodes to create Equipment list
        for node in data['nodes']:
            industrial_data["Equipment"].append({
                "id": node.get('id'),
                "component_id": node.get('component_id'),
                "label": node.get('label'),
                "type_code": node.get('type'),
                "bounding_box": node.get('bbox')
            })
            
        # Process edges to create Pipelines list
        for i, edge in enumerate(data['edges']):
            source_node = node_map.get(edge.get('from'))
            target_node = node_map.get(edge.get('to'))
            
            if source_node and target_node:
                industrial_data["Pipelines"].append({
                    "pipeline_id": f"PL-{i+1:003}",
                    "from_equipment_id": source_node['id'],
                    "from_equipment_label": source_node['label'],
                    "from_equipment_tag": source_node['component_id'],
                    "to_equipment_id": target_node['id'],
                    "to_equipment_label": target_node['label'],
                    "to_equipment_tag": target_node['component_id'],
                    "length": edge.get('length'),
                    "confidence_score": edge.get('confidence_score'),
                    "status": edge.get('flag')
                })
                
        return industrial_data

    @staticmethod
    def create_dexpi_xml(data: Dict) -> str:
        """Converts the graph JSON to a simplified DEXPI XML format."""
        node_map = {node['id']: node for node in data['nodes']}

        # DEXPI class mapping (simplified)
        dexpi_class_map = {
            "Ball Valve": "Valve",
            "Butterfly Valve": "Valve",
            "Globe Valve": "Valve",
            "Gate Valve": "Valve",
            "Check Valve": "Valve",
            "Pump": "Pump",
            "Compressor": "Compressor",
            "Heat Exchanger": "HeatExchanger",
            "Tank": "Vessel",
            "Vessel": "Vessel",
            "Instrument": "Instrument"
        }

        # Create the root element with DEXPI namespaces
        root = ET.Element("PlantModel", {
            "xmlns": "http://docs.oasis-open.org/pid/ns/dexpi/1.3",
            "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            "xsi:schemaLocation": "http://docs.oasis-open.org/pid/ns/dexpi/1.3 DEXPI_1.3.xsd"
        })

        # Create main containers
        plant = ET.SubElement(root, "Plant")
        piping_system = ET.SubElement(root, "PipingNetworkSystem")

        # Process nodes and create Equipment elements
        for node in data['nodes']:
            dexpi_class = dexpi_class_map.get(node['label'], 'Equipment')
            
            equipment_el = ET.SubElement(plant, "Equipment", {
                "ID": node['id'],
                "TagName": node['component_id'],
                "ComponentClass": dexpi_class,
                "ComponentName": node['label']
            })

        # Process edges and create PipingNetworkSegment elements
        for edge in data['edges']:
            segment_el = ET.SubElement(piping_system, "PipingNetworkSegment", {
                "ID": f"PNS-{edge['from']}-{edge['to']}"
            })
            
            # Connection from source
            ET.SubElement(segment_el, "Connection", {
                "FromID": edge['from'],
                "ToID": segment_el.get('ID')
            })
            
            # Connection to target
            ET.SubElement(segment_el, "Connection", {
                "FromID": segment_el.get('ID'),
                "ToID": edge['to']
            })

        # Pretty print the XML
        xml_str = ET.tostring(root, 'utf-8')
        parsed_str = minidom.parseString(xml_str)
        return parsed_str.toprettyxml(indent="  ")

    @staticmethod
    def industrial_json_to_base64(industrial_data: Dict) -> str:
        """Converts industrial JSON to base64 encoded string."""
        clean_data = PIDAnalysisService.clean_nan_values(industrial_data)
        json_str = json.dumps(clean_data, indent=2)
        json_bytes = json_str.encode('utf-8')
        return base64.b64encode(json_bytes).decode('utf-8')

    @staticmethod
    def dexpi_xml_to_base64(xml_string: str) -> str:
        """Converts DEXPI XML to base64 encoded string."""
        xml_bytes = xml_string.encode('utf-8')
        return base64.b64encode(xml_bytes).decode('utf-8')

    @staticmethod
    def print_graph_summary(nodes: List[Dict], edges: List[Dict]) -> str:
        """Returns a detailed, human-readable summary of all connections."""
        summary_lines = ["\n--- 📊 P&ID Connection Summary ---"]
        
        node_map = {node['id']: node for node in nodes}
        
        if not edges:
            summary_lines.append("No connections were found.")
            return "\n".join(summary_lines)

        for i, edge in enumerate(edges):
            from_node = node_map.get(edge['from'])
            to_node = node_map.get(edge['to'])
            
            if not from_node or not to_node:
                continue

            from_label = f"{from_node['label']} ({from_node['component_id']})"
            to_label = f"{to_node['label']} ({to_node['component_id']})"
            score = edge['confidence_score']
            flag = edge['flag']
            
            flag_icon = "⚠️" if flag == "LOW_CONFIDENCE_CONNECTION" else "✅"

            summary_lines.extend([
                f"\n🔗 Connection #{i+1}:",
                f"   ➡️ From: {from_label}",
                f"   ➡️ To:   {to_label}",
                f"   {flag_icon} Confidence: {score} ({flag})"
            ])
        
        return "\n".join(summary_lines)

    @staticmethod
    def generate_pipe_statistics(nodes: List[Dict], edges: List[Dict]) -> Optional[pd.DataFrame]:
        """Creates a pandas DataFrame with detailed stats for every pipe."""
        node_map = {node['id']: node for node in nodes}
        records = []

        for edge in edges:
            from_node = node_map.get(edge['from'])
            to_node = node_map.get(edge['to'])

            if not from_node or not to_node:
                continue
                
            length = edge['length']
            confidence = edge['confidence_score']
            
            if pd.isna(length) or np.isinf(length):
                length = 0.0
            if pd.isna(confidence) or np.isinf(confidence):
                confidence = 0.0
                
            records.append({
                "From Component": from_node['label'],
                "From Tag": from_node['component_id'],
                "To Component": to_node['label'],
                "To Tag": to_node['component_id'],
                "Length (px)": round(float(length), 2),
                "Confidence Score": round(float(confidence), 3),
                "Status": "Low Confidence" if edge['flag'] == "LOW_CONFIDENCE_CONNECTION" else "High Confidence"
            })
            
        if not records:
            return None
            
        df = pd.DataFrame(records)
        df = df.fillna({
            "From Component": "Unknown",
            "From Tag": "N/A", 
            "To Component": "Unknown",
            "To Tag": "N/A",
            "Length (px)": 0.0,
            "Confidence Score": 0.0,
            "Status": "Unknown"
        })
        
        return df

    @staticmethod
    def dataframe_to_excel_base64(df: pd.DataFrame) -> str:
        """Converts DataFrame to Excel and returns as base64 encoded string."""
        df_clean = df.fillna("N/A")
        
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df_clean.to_excel(writer, sheet_name='Pipe Statistics', index=False)
        
        output.seek(0)
        excel_data = output.getvalue()
        return base64.b64encode(excel_data).decode('utf-8')

    def process_pid_analysis(self, excel_file: UploadFile, image_file: UploadFile) -> Dict:
        """Main processing pipeline for P&ID analysis."""
        try:
            # 1. Load components
            nodes, comp_centers = self.load_components_from_excel(excel_file)
            
            if not nodes:
                return {
                    "success": False,
                    "error": "Failed to load components from Excel file",
                    "raw_graph_json_base64": None,
                    "industrial_json_base64": None,
                    "dexpi_xml_base64": None,
                    "statistics_excel_base64": None,
                    "summary": None,
                    "low_confidence_stats": None
                }
            
            # 2. Detect pipes
            pipes = self.detect_pipes(image_file)
            
            # 3. Build connections
            edges = self.build_graph_with_kdtree(pipes, comp_centers)
            
            # 4. Create raw graph data
            raw_graph_data = {"nodes": nodes, "edges": edges}
            
            # 5. Generate all output formats
            raw_graph_json_base64 = self.export_to_json_base64(nodes, edges)
            
            # 6. Create industrial JSON format
            industrial_data = self.create_structured_json(raw_graph_data)
            industrial_json_base64 = self.industrial_json_to_base64(industrial_data)
            
            # 7. Create DEXPI XML format
            dexpi_xml_string = self.create_dexpi_xml(raw_graph_data)
            dexpi_xml_base64 = self.dexpi_xml_to_base64(dexpi_xml_string)
            
            # 8. Generate summary and statistics
            summary = self.print_graph_summary(nodes, edges)
            
            pipe_stats_df = self.generate_pipe_statistics(nodes, edges)
            statistics_excel_base64 = None
            low_confidence_stats = None
            
            if pipe_stats_df is not None:
                statistics_excel_base64 = self.dataframe_to_excel_base64(pipe_stats_df)
                
                low_confidence_df = pipe_stats_df[pipe_stats_df['Status'] == "Low Confidence"]
                if not low_confidence_df.empty:
                    low_confidence_stats = PIDAnalysisService.clean_nan_values(
                        low_confidence_df.to_dict('records')
                    )
            
            return {
                "success": True,
                "error": None,
                "industrial_json_base64": industrial_json_base64,
                "dexpi_xml_base64": dexpi_xml_base64,
                "statistics_excel_base64": statistics_excel_base64,
                "summary": summary,
                "low_confidence_stats": low_confidence_stats,
                "total_connections": len(edges),
                "total_components": len(nodes),
                "pipes_detected": len(pipes)
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": f"Processing failed: {str(e)}",
                "raw_graph_json_base64": None,
                "industrial_json_base64": None,
                "dexpi_xml_base64": None,
                "statistics_excel_base64": None,
                "summary": None,
                "low_confidence_stats": None
            }
